//////////////////////////////////////////////////////////////////////////////
//
// AP CS A
// Unit Programming Project
//
// Fraction Calculator
//
// written by Aryan Da Boss
//

import java.util.Scanner;

public class FracCalc {

    ////////////////////////////////////////////////////////
    // 
    // the main method is where you will interact with the
    // user by prompting for input and displaying results
    //
    public static void main(String[] args) {
        // (Checkpoint 1)
        //  * prompt the user for an equation
        //  * capture the input
        //  * call the produceAnswer() method
        //  * display the result
    	
        Scanner console = new Scanner (System.in);
        System.out.println("What's your equation: ");
        String input = console.nextLine();
        input = input.toLowerCase();
        //gets user input
        while (!(input.equals("quit"))) { 	
        String result = produceAnswer(input);
        System.out.println(result);
        System.out.println("What's your equation: ");
        input = console.nextLine();
        input = input.toLowerCase();
        }
        //Sentinel loop to see if they use quit
        
        // (Checkpoint 2)
        System.out.println("Thank you for using FracCalc!");
        console.close();
    }

    ////////////////////////////////////////////////////////
    //
    // do not modify this method other than to activate the
    // checkpoint method that you are currently working on.
    //
    // after you finish Checkpoint #1, then comment out the
    // Checkpoint1 call and uncomment the Checkpoint2 call.
    // work on Checkpoint2 until all Checkpoint2 tests pass.
    //
    // after you finish Checkpoint #2, then comment out the
    // Checkpoint2 call and uncomment the Checkpoint3 call.
    // work on Checkpoint3 until all Checkpoint2 tests pass.
    //
    // And so forth.
    //
    ////////////////////////////////////////////////////////
    public static String produceAnswer(String input) { 

        // Checkpoint #1
        //return produceAnswerCheckpoint1(input);

        // Checkpoint #2
        //return produceAnswerCheckpoint2(input);

        // Checkpoint #3
        //return produceAnswerCheckpoint3(input);

        // Final Checkpoint
        return produceAnswerFinal(input);

        // Extra Credit (optional)
        //return produceAnswerExtraCredit(input);
    }

    public static String produceAnswerCheckpoint1(String input) { 
        // (Checkpoint 1):
        // break up the input parameter into three Strings: the 
        // first operand (fraction), the operator (+ - * /), and 
    	// the second operand (fraction). return second operand.
       
    	int index = input.lastIndexOf(" ");
       	
       	String firstOperand = input.substring(0, index-2) ;
       	String operator = input.substring(index-1, index);
       	String secondOperand = input.substring(index+1);

        return secondOperand;
    }

    public static String produceAnswerCheckpoint2(String input) { 
        // (Checkpoint 2):
        // break up the input parameter into three Strings: the 
        // first operand (fraction), the operator (+ - * /), and 
        // the second operand (fraction).  parse each operand
        // into three values, one each for the numerator,
        // denominator, and whole portion (for mixed fractions 
        // or integers).  return a string that describes each 
        // component of the second operand.  
        //    
        // The return format is as follows:
        //
        //     "whole:[w] numerator:[n] denominator:[d]"
        //
        // where [w], [n], and [d] represent the whole number,
        // numerator, and denominator components of the second 
        // operand.
        //
        // Example #1
        // if input is "5_3/4 - 6_5/8", the method would return
        // "whole:6 numerator:5 denominator:8"
        // 
        // Example #2
        // if input is "-3/7 - 20", the method would return
        // "whole:20 numerator:0 denominator:1"
        // 
        // Example #3
        // if input is "-32 - 27/21", the method would return
        // "whole:0 numerator:27 denominator:21"
    	
    	int index = input.lastIndexOf(" ");
    	String whole = ""; 
    	String numerator = "";
    	String denominator = "";
       	
       	String firstOperand = input.substring(0, index-2) ;
       	String operator = input.substring(index-1, index);
       	String secondOperand = input.substring(index+1);
       	
       	int indexofDivisor = secondOperand.indexOf("/");
       	index = secondOperand.indexOf("_");
       	if (index != -1) {
       		whole = secondOperand.substring(0, index);	
       	}
       	else if (indexofDivisor == -1) {
       		whole = secondOperand;	
       	}
       	else {
       		whole = "0";
       	}
       	    	
       	if (indexofDivisor != -1) {
       		if (!(whole.equals(""))) {
       			int index2 = secondOperand.lastIndexOf("_");
       			numerator = secondOperand.substring(index2+1, indexofDivisor);
       		}
       		else {
       			int index2 = secondOperand.lastIndexOf(" ");
           		numerator = secondOperand.substring(index2+1, indexofDivisor);
       		}
       	}
       	else {
       		numerator = "0";
       	}

       	if (indexofDivisor != -1) {
       		denominator = secondOperand.substring(indexofDivisor+1);
       	}
       	else {
       		denominator = "1";
       	}
       	
       	String result = "whole:"+ whole +" numerator:"+ numerator +" denominator:"+ denominator;
        //Check the different conditions for different scenarios to figure out what is the whole number, numerator, and denominator of the second operand
        return result;
    }

    public static String produceAnswerCheckpoint3(String input) { 
        // (Checkpoint 3):
        // evaluate the input as two fractional operands and an
        // arithmetic operator, and return the actual answer of
        // that calculation.  The answer need not be in reduced 
        // form and need not be a mixed fraction, but it must 
        // be correct.
        //
        // HINT: 
        // use the Integer.parseInt(string) method to convert a 
        // string to its numeric equivalent.

    	int index = input.lastIndexOf(" ");
    	String whole1 = ""; 
    	String whole2 = "";
    	String numerator1 = "";
    	String numerator2 = "";
    	String denominator1 = "";
    	String denominator2 = "";
       	
       	String firstOperand = input.substring(0, index-2) ;
       	String operator = input.substring(index-1, index);
       	String secondOperand = input.substring(index+1);
       
       	/*|||||||||||||||||||||||||||
       	|||||||||||||||||||||||||||||* 
       	|||||||||||||||||||||||||||||* 
       	||This is for first operand||* 
       	|||||||||||||||||||||||||||||* 
       	|||||||||||||||||||||||||||||* 
        |||||||||||||||||||||||||||*/
       	
       	int indexofDivisor1 = firstOperand.indexOf("/");
       	index = firstOperand.indexOf("_");
       	//finds whole number
       	if (index != -1) {
       		whole1 = firstOperand.substring(0, index);	
       	}
       	else if (indexofDivisor1 == -1) {
       		whole1 = firstOperand;	
       	}
       	else {
       		whole1 = "0";
       	}
       	//Finds numerator
       	if (indexofDivisor1 != -1) {
       		if (!(whole1.equals(""))) {
       			int index2 = firstOperand.lastIndexOf("_");
       			numerator1 = firstOperand.substring(index2+1, indexofDivisor1);
       		}
       		else {
       			int index2 = firstOperand.lastIndexOf(" ");
           		numerator1 = firstOperand.substring(index2+1, indexofDivisor1);
       		}
       	}
       	else {
       		numerator1 = "0";
       	}
       	//find denominator
       	if (indexofDivisor1 != -1) {
       		denominator1 = firstOperand.substring(indexofDivisor1+1);
       	}
       	else {
       		denominator1 = "1";
       	}
       	
       	/*|||||||||||||||||||||||||||
       	|||||||||||||||||||||||||||||* 
       	|||||||||||||||||||||||||||||* 
       	|This is for second operand||* 
       	|||||||||||||||||||||||||||||* 
       	|||||||||||||||||||||||||||||* 
        |||||||||||||||||||||||||||*/
       	
       	int indexofDivisor2 = secondOperand.indexOf("/");
       	index = secondOperand.indexOf("_");
       	//finds whole number
       	if (index != -1) {
       		whole2 = secondOperand.substring(0, index);	
       	}
       	else if (indexofDivisor2 == -1) {
       		whole2 = secondOperand;	
       	}
       	else {
       		whole2 = "0";
       	}
       	//Finds numerator
       	if (indexofDivisor2 != -1) {
       		if (!(whole2.equals(""))) {
       			int index2 = secondOperand.lastIndexOf("_");
       			numerator2 = secondOperand.substring(index2+1, indexofDivisor2);
       		}
       		else {
       			int index2 = secondOperand.lastIndexOf(" ");
           		numerator2 = secondOperand.substring(index2+1, indexofDivisor2);
       		}
       	}
       	else {
       		numerator2 = "0";
       	}
       	//find denominator
       	if (indexofDivisor2 != -1) {
       		denominator2 = secondOperand.substring(indexofDivisor2+1);
       	}
       	else {
       		denominator2 = "1";
       	}
       	
       	
       	//Calculator Part//
       	
       	int Firstwhole = Integer.parseInt(whole1);
       	int Secondwhole = Integer.parseInt(whole2);
       	int Firstnumerator = Integer.parseInt(numerator1);
       	int Secondnumerator = Integer.parseInt(numerator2);
       	int Firstdenominator = Integer.parseInt(denominator1);
       	int Seconddenominator = Integer.parseInt(denominator2);
       	String result = "";
		int resultnumerator;
   		int resultdenominator;
   		
       	//Figure out which operation to use
       	if (operator.equals("+")) {
       		
       			int n1 = 0;
       			int n2 = 0;
  
       			
       			if ((Firstwhole!=0) && (Firstnumerator!=0)) {
       				if((Firstwhole<=0) || (Firstnumerator<=0)) {
       					n1= Firstdenominator*Firstwhole-Firstnumerator; 
       				}
       				else {
       					n1= Firstdenominator*Firstwhole+Firstnumerator;
       				}			
       			}
       			
       			if ((Secondwhole!=0) && (Secondnumerator!=0)) {	
       				if((Secondwhole<=0) || (Secondnumerator<=0)) {
       					n2= Seconddenominator*Secondwhole-Secondnumerator; 
       				}
       				else {
       					n2= Seconddenominator*Secondwhole+Secondnumerator;
       				}
       			}
       			
       			if ((Firstwhole==0) && (Firstnumerator!=0)) {
       				n1= Firstnumerator;      			
       			}
       			
       			if ((Secondwhole==0) && (Secondnumerator!=0)) {	
       				n2 = Secondnumerator;
       			}
       			
       			if ((Firstwhole!=0) && (Firstnumerator==0)) {
       				n1= Firstwhole;      			
       			}
       			
       			if ((Secondwhole!=0) && (Secondnumerator==0)) {	
       				n2 = Secondwhole;
       			}
       		
       			resultnumerator = n1+n2;
   				resultdenominator = Firstdenominator;
   				
       			if(Firstdenominator!=Seconddenominator) {
       				resultdenominator = Firstdenominator*Seconddenominator;
       				resultnumerator = (n1*Seconddenominator)+(n2*Firstdenominator);
       			}

       			result = resultnumerator+"/"+resultdenominator;
       			
       	}
       	
       	else if (operator.equals("-")) {
       		
       		int n1 = 0;
   			int n2 = 0;
   			
   			if ((Firstwhole!=0) && (Firstnumerator!=0)) {
   				if((Firstwhole<=0) || (Firstnumerator<=0)) {
   					n1= Firstdenominator*Firstwhole-Firstnumerator; 
   				}
   				else {
   					n1= Firstdenominator*Firstwhole+Firstnumerator;
   				}
   			}
   			
   			if ((Secondwhole!=0) && (Secondnumerator!=0)) {	
   				if((Secondwhole<=0) || (Secondnumerator<=0)) {
   					n2= Seconddenominator*Secondwhole-Secondnumerator; 
   				}
   				else {
   					n2= Seconddenominator*Firstwhole+Secondnumerator;
   				}
   			}
   			
   			if ((Firstwhole==0) && (Firstnumerator!=0)) {
   				n1= Firstnumerator;      			
   			}
   			
   			if ((Secondwhole==0) && (Secondnumerator!=0)) {	
   				n2 = Secondnumerator;
   			}
   			
   			if ((Firstwhole!=0) && (Firstnumerator==0)) {
   				n1= Firstwhole;      			
   			}
   			
   			if ((Secondwhole!=0) && (Secondnumerator==0)) {	
   				n2 = Secondwhole;
   			}
   			
   			resultnumerator = n1-n2;
			resultdenominator = Firstdenominator;
			
   			if(Firstdenominator!=Seconddenominator) {
   				resultdenominator = Firstdenominator*Seconddenominator;
   				resultnumerator = (n1*Seconddenominator)-(n2*Firstdenominator);
   			}

   			result = resultnumerator+"/"+resultdenominator;
       		
       	}
       	
       	else if (operator.equals("*")) {
       		
       		int n1 = 0;
   			int n2 = 0;
   			
   			if ((Firstwhole!=0) && (Firstnumerator!=0)) {
   				if((Firstwhole<=0) || (Firstnumerator<=0)) {
   					n1= Firstdenominator*Firstwhole-Firstnumerator; 
   				}
   				else {
   					n1= Firstdenominator*Firstwhole+Firstnumerator;
   				}	
   			}
   			
   			if ((Secondwhole!=0) && (Secondnumerator!=0)) {	
   				if((Secondwhole<=0) || (Secondnumerator<=0)) {
   					n2= Seconddenominator*Secondwhole-Secondnumerator; 
   				}
   				else {
   					n2= Seconddenominator*Firstwhole+Secondnumerator;
   				}
   			}
   			
   			if ((Firstwhole==0) && (Firstnumerator!=0)) {
   				n1= Firstnumerator;      			
   			}
   			
   			if ((Secondwhole==0) && (Secondnumerator!=0)) {	
   				n2 = Secondnumerator;
   			}
   			
   			if ((Firstwhole!=0) && (Firstnumerator==0)) {
   				n1= Firstwhole;      			
   			}
   			
   			if ((Secondwhole!=0) && (Secondnumerator==0)) {	
   				n2 = Secondwhole;
   			}
   			
   			resultnumerator = n1*n2;
			resultdenominator = Firstdenominator*Seconddenominator;
   			
   			result = resultnumerator+"/"+resultdenominator;
       		
       	}
       	
       	else if (operator.equals("/")) {
       		
       		int n1 = 0;
   			int n2 = 0;
   			
   			if ((Firstwhole!=0) && (Firstnumerator!=0)) {
   				if((Firstwhole<=0) || (Firstnumerator<=0)) {
   					n1= Firstdenominator*Firstwhole-Firstnumerator; 
   				}
   				else {
   					n1= Firstdenominator*Firstwhole+Firstnumerator;
   				}  			
   			}
   			
   			if ((Secondwhole!=0) && (Secondnumerator!=0)) {	
   				if((Secondwhole<=0) || (Secondnumerator<=0)) {
   					n2= Seconddenominator*Secondwhole-Secondnumerator; 
   				}
   				else {
   					n2= Seconddenominator*Secondwhole+Secondnumerator;
   				}
   			}
   			
   			if ((Firstwhole==0) && (Firstnumerator!=0)) {
   				n1= Firstnumerator;      			
   			}
   			
   			if ((Secondwhole==0) && (Secondnumerator!=0)) {	
   				n2 = Secondnumerator;
   			}
   			
   			if ((Firstwhole!=0) && (Firstnumerator==0)) {
   				n1= Firstwhole;      			
   			}
   			
   			if ((Secondwhole!=0) && (Secondnumerator==0)) {	
   				n2 = Secondwhole;
   			}
   			
   			resultnumerator = n1*Seconddenominator;
			resultdenominator = Firstdenominator * n2;
   			
			if (resultdenominator < 0) {
				resultnumerator *= -1;
				resultdenominator = Math.abs(resultdenominator);	
			}
			
   			result = resultnumerator+"/"+resultdenominator;
       		
       	}
       	
       	
        return result;
    }

    public static String produceAnswerFinal(String input) {
    	 
        //  (Final Checkpoint):
        // in addition to the requirements for Checkpoint #3,
        // all answers must be reduced.
    	// input = 5_3/4 - 6_5/8, output = -7/8
 
    	int index = input.lastIndexOf(" ");
    	String whole1 = ""; 
    	String whole2 = "";
    	String numerator1 = "";
    	String numerator2 = "";
    	String denominator1 = "";
    	String denominator2 = "";
       	int resultnumerator = 0;
       	int resultdenominator = 0;
       	String firstOperand = input.substring(0, index - 2) ;
       	String operator = input.substring(index - 1, index);
       	String secondOperand = input.substring(index + 1);
       
       	/*|||||||||||||||||||||||||||
       	|||||||||||||||||||||||||||||* 
       	|||||||||||||||||||||||||||||* 
       	||This is for first operand||* 
       	|||||||||||||||||||||||||||||* 
       	|||||||||||||||||||||||||||||* 
        |||||||||||||||||||||||||||*/
       	
       	int indexofDivisor1 = firstOperand.indexOf("/");
       	index = firstOperand.indexOf("_");
       	//finds whole number
       	if (index != -1 && indexofDivisor1!=-1) {
       		whole1 = firstOperand.substring(0, index);
       		numerator1 = firstOperand.substring(index+1, indexofDivisor1);
       		denominator1 = firstOperand.substring(indexofDivisor1+1);
       	}
       	else if (indexofDivisor1 != -1) {
       		whole1 = "0";
       		numerator1 = firstOperand.substring(0, indexofDivisor1);
       		denominator1 = firstOperand.substring(indexofDivisor1+1);
       	}
       	else if (indexofDivisor1 == -1) {
       		whole1 = firstOperand;
       		denominator1 = "1";
       		numerator1 = "0";
       	}
       	       	     	
       	/*|||||||||||||||||||||||||||
       	|||||||||||||||||||||||||||||* 
       	|||||||||||||||||||||||||||||* 
       	|This is for second operand||* 
       	|||||||||||||||||||||||||||||* 
       	|||||||||||||||||||||||||||||* 
        |||||||||||||||||||||||||||*/
       	
       	int indexofDivisor2 = secondOperand.indexOf("/");
       	index = secondOperand.indexOf("_");
       	//finds whole number
       	if (index != -1 && indexofDivisor2!=-1) {
       		whole2 = secondOperand.substring(0, index);
       		numerator2 = secondOperand.substring(index+1, indexofDivisor2);
       		denominator2 = secondOperand.substring(indexofDivisor2+1);
       	}
       	else if (indexofDivisor2 != -1) {
       		whole2 = "0";
       		numerator2 = secondOperand.substring(0, indexofDivisor2);
       		denominator2 = secondOperand.substring(indexofDivisor2+1);
       	}
       	else if (indexofDivisor2 == -1) {
       		whole2 = secondOperand;
       		denominator2 = "1";
       		numerator2 = "0";
       	}
       	
       	
       	//Calculator Part
       	
       	int Firstwhole = Integer.parseInt(whole1);
       	int Secondwhole = Integer.parseInt(whole2);
       	int Firstnumerator = Integer.parseInt(numerator1);
       	int Secondnumerator = Integer.parseInt(numerator2);
       	int Firstdenominator = Integer.parseInt(denominator1);
       	int Seconddenominator = Integer.parseInt(denominator2);
       	String result = "";

       	
       	//Figure out which operation to use
       	if (operator.equals("+") || operator.equals("-")) {
       		
       			int n1 = 0;
       			int n2 = 0;
       			
       		//Doing first operand computations
       			
       			//This checks if its a mixed numeral e.g. 3/8 - 6_3/8
       			if ((Firstwhole!= 0) && (Firstnumerator!= 0)) {
       				
       				n1 = Firstdenominator * Math.abs(Firstwhole) + Firstnumerator;
       				
       				if(Firstwhole < 0)  {
       					n1 *= -1; 
       				}			
       			}
       			
       			//Its a simple fraction
       			if ((Firstwhole == 0) && (Firstnumerator!= 0)) {
       				n1 = Firstnumerator;      			
       			}
       		
       			//This checks if its a whole number
       			if ((Firstwhole != 0) && (Firstnumerator == 0)) {
       				n1 = Firstwhole;      			
       			}
       			
       		//Doing second operand computations
       			
       			//This checks if its a mixed numeral e.g. 3/8 - 6_3/8
       			if ((Secondwhole!= 0) && (Secondnumerator!= 0)) {	
       				
       				n2 = Seconddenominator * Math.abs(Secondwhole) + Secondnumerator;
       				
       				if(Secondwhole < 0) {
       					n2 *= -1; 
       				}
       			}
       			
       			//This is a simple fraction
       			if ((Secondwhole == 0) && (Secondnumerator !=0)) {	
       				n2 = Secondnumerator;
       			}
       			
       			//This checks if its a whole number
       			if ((Secondwhole!=0) && (Secondnumerator==0)) {	
       				n2 = Secondwhole;
       			}
       			
   				
   				if(Firstdenominator != Seconddenominator) {
       				resultdenominator = Firstdenominator * Seconddenominator;
       				if(operator.equals("+")) {
       					resultnumerator = (n1 * Seconddenominator) + (n2 * Firstdenominator);
       				}
       				else {
       					resultnumerator = (n1 * Seconddenominator) - (n2 * Firstdenominator);
       				}
       			}
   				else {
   		       		//Checks to see which operation to use
   	       			if (operator.equals("+")) {
   	       				resultnumerator = n1 + n2;
   	       			}
   	       			else {
   	       				resultnumerator = n1 - n2;
   	       			}
   	       			
   	   				resultdenominator = Firstdenominator;
   				}
       	}
       	
      	
       	else if (operator.equals("*") || operator.equals("/")) {
       		
       		int n1 = 0;
   			int n2 = 0;
   			
   		//Doing first operand computations
   			
   			//This checks if its a mixed numeral e.g. 3/8 * 6_3/8
   			if ((Firstwhole!= 0) && (Firstnumerator!= 0)) {
   				
   				n1 = Firstdenominator * Math.abs(Firstwhole) + Firstnumerator;
   				
   				if(Firstwhole < 0)  {
   					n1 *= -1; 
   				}			
   			}
   			
   			//Its a simple fraction
   			if ((Firstwhole == 0) && (Firstnumerator!= 0)) {
   				n1 = Firstnumerator;      			
   			}
   		
   			//This checks if its a whole number
   			if ((Firstwhole != 0) && (Firstnumerator == 0)) {
   				n1 = Firstwhole;      			
   			}
   			
   		//Doing second operand computations
   			
   			//This checks if its a mixed numeral e.g. 3/8 - 6_3/8
   			if ((Secondwhole!= 0) && (Secondnumerator!= 0)) {	
   				
   				n2 = Seconddenominator * Math.abs(Secondwhole) + Secondnumerator;
   				
   				if(Secondwhole < 0) {
   					n2 *= -1; 
   				}
   			}
   			
   			//This is a simple fraction
   			if ((Secondwhole == 0) && (Secondnumerator != 0)) {	
   				n2 = Secondnumerator;
   			}
   			
   			//This checks if its a whole number
   			if ((Secondwhole != 0) && (Secondnumerator == 0)) {	
   				n2 = Secondwhole;
   			}
   			
   		//Checks to see which operation to use
   			if (operator.equals("*")) {
   				resultnumerator = n1 * n2;
   				resultdenominator = Firstdenominator * Seconddenominator;
   			}
   			else {
   				resultnumerator = n1 * Seconddenominator;
   				resultdenominator = Firstdenominator * n2;
   			}
       	}
       	
   		if (resultnumerator == 0) {
   			return "0";
   		}
       	
       	Integer resultwhole = 0;
       	
       //find the GreatestCommonFactor (greatest common factor)
      
       	if(Math.abs(resultnumerator) % Math.abs(resultdenominator) != 0) {
       		
       		int GreatestCommonFactor = Math.abs(resultnumerator);
        
       		while (Math.abs(resultdenominator) % GreatestCommonFactor != 0 || Math.abs(resultnumerator) % GreatestCommonFactor != 0) {
       			GreatestCommonFactor--;
       		}

       		resultdenominator = resultdenominator/GreatestCommonFactor;
       		resultnumerator = resultnumerator/GreatestCommonFactor;
       	}
       	
        //To return the correct result compute whole number
       	if(resultnumerator % resultdenominator == 0 || Math.abs(resultdenominator) == 1) {
            resultwhole = resultnumerator / resultdenominator; 
            return resultwhole.toString();
        }
   		
       	if (Math.abs(resultnumerator) > Math.abs(resultdenominator))  {
   		 	resultwhole = resultnumerator/resultdenominator;
   			resultnumerator = Math.abs(resultnumerator) % Math.abs(resultdenominator);
   		}
   		else if(Math.abs(resultnumerator) == Math.abs(resultdenominator)) {
   			resultwhole = resultnumerator/resultdenominator;
   			return resultwhole.toString();
        }
       	
       	// If whole number is negative
       	if(resultwhole != 0) {
   			resultdenominator = Math.abs(resultdenominator);
   			resultnumerator = Math.abs(resultnumerator);
   	        return resultwhole + "_" + resultnumerator + "/" + resultdenominator; 
   		}
       	else { 
       		if((resultdenominator > 0 && resultnumerator < 0) || (resultdenominator < 0 && resultnumerator > 0)) {
       			if(resultnumerator > 0) {
       				resultnumerator *= -1;
       			}
       		}
   			resultdenominator = Math.abs(resultdenominator);
       		return resultnumerator + "/" + resultdenominator; 
       	}
    }
    
    public static String produceAnswerExtraCredit(String input) { 
        // TODO (Extra Credit, optional): 
        // can evaluate an arbitrarily amount of operands and 
        // operators.  Equations are evaluated according to 
        // rules of precedence.

        /** not yet implemented **/
        return null;
    }
}
