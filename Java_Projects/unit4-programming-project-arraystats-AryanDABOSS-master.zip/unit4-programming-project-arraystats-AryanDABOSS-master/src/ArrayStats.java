//////////////////////////////////////////////////////////////////////////////
//
// AP CS A
// Unit 4 Lesson 8 
// Programming Project
//
// Basic Array Statistics
//
// written by {Aryan}
//
import java.util.Scanner;
import java.util.Arrays;

public class ArrayStats {

    public static void main(String[] args) {
    	
        // I prompt the user for the size of the data set
    	
    	Scanner input = new Scanner(System.in);
    	System.out.println("Input a positive number for the size of the data set: ");
    	int size = input.nextInt();
    	
        // I create an array to hold the data values
    	
    	int [] arr = new int [size];
    	
        // I prompt the user for the values using a loop
    	
    	for (int i = 0; i < size; i++) {
    		System.out.println ("Please enter a number to add to your data set: ");
    		int data = input.nextInt();
    		arr[i] = data;
    	}
    	
        // I sort the array below using the .sort() method
    	
        Arrays.sort(arr);
        
        // I print the contents of the array after turning it into a String
        
        System.out.println(Arrays.toString(arr));
        
        // 	I call each of the following methods (which I
        //  define below) and capture the result. The names 
        //  of the methods match exactly (case included).
        //
        //         a. max(array)
        //         b. min(array)
        //         c. range(array)
        //         d. mode(array)
        //         e. median(array)
        //         f. mean(array)
        //         g. stddev(array)
        //         h. percentEven(array)
        //         i. percentOdd(array)
        //         j. largestGap(array)
        //         k. smallestGap(array)
        //
        // I display each of the statistical properties below by printing them out
        
        int max = max(arr);
        System.out.println("The max of the data set is: " + max);
        
        int min = min (arr);
        System.out.println("The min of the data set is: " + min);
        
        int range = range(arr);
        System.out.println("The range of the data set is: " + range);
        
        int mode = mode(arr);
        System.out.println("The mode of the data set is: " + mode);
        
        double median = median(arr);
        System.out.println("The median of the data set is: " + median);
        
        double mean = mean(arr);
        System.out.println("The mean of the data set is: " + mean);
        
        double stddev = stddev(arr);
        System.out.println("The standard deviation of the data set is: " + stddev);
        
        double percentEven = percentEven(arr);
        System.out.println("The percentage of even numbers in the data set is: " + percentEven);
        
        double percentOdd = percentOdd(arr);
        System.out.println("The percentage of odd numbers in the data set is: " + percentOdd);
        
        int largestGap = largestGap(arr);
        System.out.println("The largest gap between consecutive numbers in the data set is: " + largestGap);
        
        int smallestGap = smallestGap(arr);
        System.out.println("The smallest gap between consecutive numbers in the data set is: " + smallestGap);
        
        input.close();
    }
    
    //       I define the methods to calculate each of the statistical
    //       properties as listed above.  For example:
    //
    //           public static int max(int[] array) { ... }
    
    //This method finds the max value in the data set
    public static int max (int [] array) {
    	int max = array[array.length-1];
    	return max;
    }
  
    //This method finds the min value in the data set
    public static int min (int [] array) {
    	int min = array[0];
    	return min;
    }
    
    //This method uses the max and min methods to find the range of the data set
    public static int range (int [] array) {
    	int range = max(array) - min(array);
    	return range;
    }
    
    //This method finds the mode of the data set
    public static int mode(int [] array) {
        int mode = 0;
        int maxCount = 0;

        for (int i = 0; i < array.length; i++) {
           int count = 0;
           for (int j = 0; j < array.length; j++) {
              if (array[j] == array[i])
              count++;
           }
           if (count > maxCount) {
              maxCount = count;
              mode = array[i];
           }
        }
        return mode;
     }
    
    //This method finds the median of the data set
    public static double median (int [] array) {
    	if (array.length % 2 != 0) {
            return (double) array[array.length / 2];
    	}
    	else {
        return (double)(array[(array.length - 1) / 2] + array[array.length / 2]) / 2.0;
    	}
    }
    
    //This method finds the mean of the data set
    public static double mean (int [] array) {
    	double mean = 0;
    	for (int i = 0; i < array.length; i++) {
    		mean += array[i];
    	}
    	mean /= array.length;
    	return mean;
    }

    //This method uses the mean method to find the standard deviation of the data set
    public static double stddev (int [] array) {
    	double stddev = 0;
    	for (int i = 0; i < array.length; i++) {
    		stddev += Math.pow(array[i] - mean (array), 2);
    	}
    	stddev = Math.pow(stddev/array.length, 0.5);
    	return stddev;
    }
    
    //This method finds the amount of data entries that are even and divides it by the total number of terms
    public static double percentEven (int [] array) {
    	double percent = 0.0;
    	int count = 0;
    	for (int i = 0; i < array.length; i++) {
    		if(array[i] % 2 == 0) {
    			count++;
    		}
    	}
    	percent = (count*100.0)/(array.length*1.0);
    	return percent;
    }
    
    //This method finds the amount of data entries that are odd and divides it by the total number of terms
    public static double percentOdd (int [] array) {
    	double percent = 0.0;
    	int count = 0;
    	for (int i = 0; i < array.length; i++) {
    		if(array[i] % 2 != 0) {
    			count++;
    		}
    	}
    	percent = (count*100.0)/(array.length*1.0);
    	return percent;
    }
    
    //This method finds the largest gap between consecutive (sorted) numbers in the data set
    public static int largestGap(int [] array) {
        int gap = 0;
        if (array.length == 1) {
        	gap = 0;
        }
        else {
        	for (int i = 1; i < array.length; i++) {
        		int difference = array[i] - array[i-1];
        		if (difference > gap) {
        			gap = difference;
        		}
        	}
        }
        return gap;
    }
 
    //This method finds the smallest gap between between consecutive (sorted) numbers in the data set
    public static int smallestGap(int [] array) {
        int gap;
    	if (array.length == 1) {
        	gap = 0;
        }
        else {
        	gap = array[1] - array[0];
        	for (int i = 1; i < array.length; i++) {
        		int difference = array[i] - array[i-1];
        		if (difference < gap) {
        			gap = difference;
        		}
        	}
        }
        return gap;
    }
    
}
