////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
//////                                                            //////
//////                  DO NOT MODIFY THIS FILE                   //////
//////                                                            //////
//////        THESE ARE NOT THE DROIDS YOU ARE LOOKING FOR        //////
//////                                                            //////
//////           MOVE ALONG THERE IS NOTHING TO SEE HERE          //////
//////                                                            //////
////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////

import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;

import org.junit.jupiter.api.Test;

class ArrayStatsTest {
    
    ////////////////////////////////////////////////////////////////
    // 
    // test max()
    // 
    @Test
    void testMax1Of2() {
        int[] array = { 111970 };
        assertEquals(111970, ArrayStats.max(array));
    }
    @Test
    void testMax2Of2() {
        int[] array = { -3, -2, -1, 0, 1, 2, 3 };
        assertEquals(3, ArrayStats.max(array));
    }

    ////////////////////////////////////////////////////////////////
    // 
    // test min()
    // 
    @Test
    void testMin1Of2() {
        int[] array = { 111970 };
        assertEquals(111970, ArrayStats.min(array));
    }
    @Test
    void testMin2Of2() {
        int[] array = { -3, -2, -1, 0, 1, 2, 3 };
        assertEquals(-3, ArrayStats.min(array));
    }

    ////////////////////////////////////////////////////////////////
    // 
    // test range()
    // 
    @Test
    void testRange1Of2() {
        int[] array = { 111970 };
        assertEquals(0, ArrayStats.range(array));
    }
    @Test
    void testRange2Of2() {
        int[] array = { -3, -2, -1, 0, 1, 2, 3 };
        assertEquals(6, ArrayStats.range(array));
    }

    ////////////////////////////////////////////////////////////////
    // 
    // test mode()
    // 
    @Test
    void testMode1Of7() {
        int[] array = { 111970 };
        assertEquals(111970, ArrayStats.mode(array));
    }
    @Test
    void testMode2Of7() {
        int[] array = { 1, 1, 19, 70 };
        assertEquals(1, ArrayStats.mode(array));
    }
    @Test
    void testMode3Of7() {
        int[] array = { 80, 83, 83, 87 };
        assertEquals(83, ArrayStats.mode(array));
    }
    @Test
    void testMode4Of7() {
        int[] array = { -1, -1, 0, 1, 1 };
        assertEquals(-1, ArrayStats.mode(array));
    }
    @Test
    void testMode5Of7() {
        int[] array = { -1, -1, 0, 0, 0, 1, 1, 1 };
        assertEquals(0, ArrayStats.mode(array));
    }
    @Test
    void testMode6Of7() {
        int[] array = { -1, -1, 0, 0, 0, 1, 1, 1, 1 };
        assertEquals(1, ArrayStats.mode(array));
    }
    @Test
    void testMode7Of7() {
        int[] array = { Integer.MAX_VALUE, Integer.MAX_VALUE };
        assertEquals(Integer.MAX_VALUE, ArrayStats.mode(array));
    }

    ////////////////////////////////////////////////////////////////
    // 
    // test median()
    // 
    @Test
    void testMedian1Of5() {
        int[] array = { 111970 };
        assertEquals(111970.0, ArrayStats.median(array), 0.0005);
    }
    @Test
    void testMedian2Of5() {
        int[] array = { -3, -2, -1, 0, 1, 2, 3 };
        assertEquals(0.0, ArrayStats.median(array), 0.0005);
    }
    @Test
    void testMedian3Of5() {
        int[] array = { 1, 1, 19, 70 };
        assertEquals(10.0, ArrayStats.median(array), 0.0005);
    }
    @Test
    void testMedian4Of5() {
        int[] array = { -70, -19, -1, -1 };
        assertEquals(-10.0, ArrayStats.median(array), 0.0005);
    }
    @Test
    void testMedian5Of5() {
        int[] array = { Integer.MIN_VALUE, Integer.MAX_VALUE };
        assertEquals(-0.5, ArrayStats.median(array), 0.0005);
    }

    ////////////////////////////////////////////////////////////////
    // 
    // test mean()
    // 
    @Test
    void testMean1Of5() {
        int[] array = { 111970 };
        assertEquals(111970.0, ArrayStats.mean(array), 0.0005);
    }
    @Test
    void testMean2Of5() {
        int[] array = { -3, -2, -1, 0, 1, 2, 3 };
        assertEquals(0.0, ArrayStats.mean(array), 0.0005);
    }
    @Test
    void testMean3Of5() {
        int[] array = { 1, 1, 19, 70 };
        assertEquals(22.75, ArrayStats.mean(array), 0.0005);
    }
    @Test
    void testMean4Of5() {
        int[] array = { -70, -19, -1, -1 };
        assertEquals(-22.75, ArrayStats.mean(array), 0.0005);
    }
    @Test
    void testMean5Of5() {
        int[] array = { Integer.MIN_VALUE, Integer.MAX_VALUE };
        assertEquals(-0.5, ArrayStats.mean(array), 0.0005);
    }

    ////////////////////////////////////////////////////////////////
    // 
    // test stddev()
    // 
    @Test
    void testStdDev1Of4() {
        int[] array = { 111970 };
        assertEquals(0.0, ArrayStats.stddev(array), 0.0005);
    }
    @Test
    void testStdDev2Of4() {
        int[] array = { -3, -2, -1, 0, 1, 2, 3 };
        assertEquals(2.0, ArrayStats.stddev(array), 0.0005);
    }
    @Test
    void testStdDev3Of4() {
        int[] array = { 1, 1, 19, 70 };
        assertEquals(28.252212, ArrayStats.stddev(array), 0.0000005);
    }
    @Test
    void testStdDev4Of4() {
        int[] array = { -70, -19, -1, -1 };
        assertEquals(28.252212, ArrayStats.stddev(array), 0.0000005);
    }

    ////////////////////////////////////////////////////////////////
    // 
    // test percentEven()
    // 
    @Test
    void testPercentEven1Of5() {
        int[] array = { 111970 };
        assertEquals(100.0, ArrayStats.percentEven(array), 0.0005);
    }
    @Test
    void testPercentEven2Of5() {
        int[] array = { -3, -2, -1, 0, 1, 2, 3 };
        assertEquals(42.857143, ArrayStats.percentEven(array), 0.0000005);
    }
    @Test
    void testPercentEven3Of5() {
        int[] array = { 1, 1, 19, 70 };
        assertEquals(25.0, ArrayStats.percentEven(array), 0.0005);
    }
    @Test
    void testPercentEven4Of5() {
        int[] array = { -70, -19, -1, -1 };
        assertEquals(25.0, ArrayStats.percentEven(array), 0.0005);
    }
    @Test
    void testPercentEven5Of5() {
        int[] array = { 1 };
        assertEquals(0.0, ArrayStats.percentEven(array), 0.0005);
    }

    ////////////////////////////////////////////////////////////////
    // 
    // test percentOdd()
    // 
    @Test
    void testPercentOdd1Of5() {
        int[] array = { 111970 };
        assertEquals(0.0, ArrayStats.percentOdd(array), 0.0005);
    }
    @Test
    void testPercentOdd2Of5() {
        int[] array = { -3, -2, -1, 0, 1, 2, 3 };
        assertEquals(57.142857, ArrayStats.percentOdd(array), 0.0000005);
    }
    @Test
    void testPercentOdd3Of5() {
        int[] array = { 1, 1, 19, 70 };
        assertEquals(75.0, ArrayStats.percentOdd(array), 0.0005);
    }
    @Test
    void testPercentOdd4Of5() {
        int[] array = { -70, -19, -1, -1 };
        assertEquals(75.0, ArrayStats.percentOdd(array), 0.0005);
    }
    @Test
    void testPercentOdd5Of5() {
        int[] array = { 1 };
        assertEquals(100.0, ArrayStats.percentOdd(array), 0.0005);
    }

    ////////////////////////////////////////////////////////////////
    // 
    // test largestGap()
    // 
    @Test
    void testLargestGap1Of5() {
        int[] array = { 111970 };
        assertEquals(0, ArrayStats.largestGap(array));
    }
    @Test
    void testLargestGap2Of5() {
        int[] array = { -3, -2, -1, 0, 1, 2, 3 };
        assertEquals(1, ArrayStats.largestGap(array));
    }
    @Test
    void testLargestGap3Of5() {
        int[] array = { 1, 1, 19, 70 };
        assertEquals(51, ArrayStats.largestGap(array));
    }
    @Test
    void testLargestGap4Of5() {
        int[] array = { -70, -19, -1, -1 };
        assertEquals(51, ArrayStats.largestGap(array));
    }
    @Test
    void testLargestGap5Of5() {
        int[] array = { 0, 0, 0 };
        assertEquals(0, ArrayStats.largestGap(array));
    }

    ////////////////////////////////////////////////////////////////
    // 
    // test smallestGap()
    // 
    @Test
    void testSmallestGap1Of5() {
        int[] array = { 111970 };
        assertEquals(0, ArrayStats.smallestGap(array));
    }
    @Test
    void testSmallestGap2Of5() {
        int[] array = { -3, -2, -1, 0, 1, 2, 3 };
        assertEquals(1, ArrayStats.smallestGap(array));
    }
    @Test
    void testSmallestGap3Of5() {
        int[] array = { 1, 1, 19, 70 };
        assertEquals(0, ArrayStats.smallestGap(array));
    }
    @Test
    void testSmallestGap4Of5() {
        int[] array = { -70, -19, -1, -1 };
        assertEquals(0, ArrayStats.smallestGap(array));
    }
    @Test
    void testSmallestGap5Of5() {
        int[] array = { 0, 0, 0 };
        assertEquals(0, ArrayStats.smallestGap(array));
    }

}
