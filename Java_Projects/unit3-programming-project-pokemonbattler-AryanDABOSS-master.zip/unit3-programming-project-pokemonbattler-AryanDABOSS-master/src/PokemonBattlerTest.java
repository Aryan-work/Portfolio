////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
//////                                                            //////
//////                  DO NOT MODIFY THIS FILE                   //////
//////                                                            //////
//////        THESE ARE NOT THE DROIDS YOU ARE LOOKING FOR        //////
//////                                                            //////
//////           MOVE ALONG THERE IS NOTHING TO SEE HERE          //////
//////                                                            //////
////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.PrintStream;

import java.util.Scanner;

class PokemonBattlerTest {

    // original stdin and stdout streams
    private InputStream originalIn = System.in;
    private PrintStream originalOut = System.out;

    @AfterEach
    public void restoreStreams() {
        System.setIn(originalIn);
        System.setOut(originalOut);
    }

    @Test
    void testGetDefender1of4() {
        // information about attacker and defender
        String attacker = "Pikachu";
        String defender = "Bulbasaur";
        // configure "user" input through stdin
        InputStream input = new ByteArrayInputStream(defender.getBytes());
        System.setIn(input);
        Scanner s = new Scanner(input);
        // capture stdout
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outputStream));
        // run the method
        String actual = PokemonBattler.getDefender(s, attacker);
        s.close();
        // capture the actual output
        String actualOutput = outputStream.toString();
        // build expected output
        String expectedOutput = getExpectedDefenderOutput(attacker, defender);
        // remove evil spirits
        actualOutput = actualOutput.replaceAll("\r\n", "\n");
        expectedOutput = expectedOutput.replaceAll("\r\n", "\n");
        // does it match?
        assertEquals(expectedOutput, actualOutput.toString().trim());
    }

    @Test
    void testGetDefender2of4() {
        // information about attacker and defender
        String attacker = "Pikachu";
        String defender = "Bulbasaur";
        // configure "user" input through stdin
        InputStream input = new ByteArrayInputStream(defender.getBytes());
        System.setIn(input);
        Scanner s = new Scanner(input);
        // capture stdout
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outputStream));
        // run the method
        String actual = PokemonBattler.getDefender(s, attacker);
        s.close();
        // does it match?
        assertEquals(defender, actual);
    }

    @Test
    void testGetDefender3of4() {
        // information about attacker and defender
        String attacker = "Giratina";
        String defender = "Mewtwo";
        // configure "user" input through stdin
        InputStream input = new ByteArrayInputStream(defender.getBytes());
        System.setIn(input);
        Scanner s = new Scanner(input);
        // capture stdout
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outputStream));
        // run the method
        String actual = PokemonBattler.getDefender(s, attacker);
        s.close();
        // capture the actual output
        String actualOutput = outputStream.toString();
        // build expected output
        String expectedOutput = getExpectedDefenderOutput(attacker, defender);
        // remove evil spirits
        actualOutput = actualOutput.replaceAll("\r\n", "\n");
        expectedOutput = expectedOutput.replaceAll("\r\n", "\n");
        // does it match?
        assertEquals(expectedOutput, actualOutput.toString().trim());
    }

    @Test
    void testGetDefender4of4() {
        // information about attacker and defender
        String attacker = "Giratina";
        String defender = "Mewtwo";
        // configure "user" input through stdin
        InputStream input = new ByteArrayInputStream(defender.getBytes());
        System.setIn(input);
        Scanner s = new Scanner(input);
        // capture stdout
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outputStream));
        // run the method
        String actual = PokemonBattler.getDefender(s, attacker);
        s.close();
        // does it match?
        assertEquals(defender, actual);
    }

    @Test
    void testGetDefenseStat1of4() {
        // information about defender
        String defender = "Bulbasaur";
        int defenseStat = 111;
        // configure "user" input through stdin
        String defenseInput = "" + defenseStat;
        InputStream input = new ByteArrayInputStream(defenseInput.getBytes());
        System.setIn(input);
        Scanner s = new Scanner(input);
        // capture stdout
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outputStream));
        // run the method
        int actual = PokemonBattler.getDefenseStat(s, defender);
        s.close();
        // capture the actual output
        String actualOutput = outputStream.toString();
        // build expected output
        String expectedOutput = getExpectedDefenseStatOutput(defender);
        // remove evil spirits
        actualOutput = actualOutput.replaceAll("\r\n", "\n");
        expectedOutput = expectedOutput.replaceAll("\r\n", "\n");
        // does it match?
        assertEquals(expectedOutput, actualOutput.toString().trim());
    }

    @Test
    void testGetDefenseStat2of4() {
        // information about defender
        String defender = "Bulbasaur";
        int defenseStat = 111;
        // configure "user" input through stdin
        String defenseInput = "" + defenseStat;
        InputStream input = new ByteArrayInputStream(defenseInput.getBytes());
        System.setIn(input);
        Scanner s = new Scanner(input);
        // capture stdout
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outputStream));
        // run the method
        int actual = PokemonBattler.getDefenseStat(s, defender);
        s.close();
        // does it match?
        assertEquals(defenseStat, actual);
    }

    @Test
    void testGetDefenseStat3of4() {
        // information about defender
        String defender = "Mewtwo";
        int defenseStat = 182;
        // configure "user" input through stdin
        String defenseInput = "" + defenseStat;
        InputStream input = new ByteArrayInputStream(defenseInput.getBytes());
        System.setIn(input);
        Scanner s = new Scanner(input);
        // capture stdout
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outputStream));
        // run the method
        int actual = PokemonBattler.getDefenseStat(s, defender);
        s.close();
        // capture the actual output
        String actualOutput = outputStream.toString();
        // build expected output
        String expectedOutput = getExpectedDefenseStatOutput(defender);
        // remove evil spirits
        actualOutput = actualOutput.replaceAll("\r\n", "\n");
        expectedOutput = expectedOutput.replaceAll("\r\n", "\n");
        // does it match?
        assertEquals(expectedOutput, actualOutput.toString().trim());
    }

    @Test
    void testGetDefenseStat4of4() {
        // information about defender
        String defender = "Mewtwo";
        int defenseStat = 182;
        // configure "user" input through stdin
        String defenseInput = "" + defenseStat;
        InputStream input = new ByteArrayInputStream(defenseInput.getBytes());
        System.setIn(input);
        Scanner s = new Scanner(input);
        // capture stdout
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outputStream));
        // run the method
        int actual = PokemonBattler.getDefenseStat(s, defender);
        s.close();
        // does it match?
        assertEquals(defenseStat, actual);
    }

    @Test
    void testDamage1of4() {
        // information about attacker and defender
        int attackStat = 112;
        int attackPower = 80;
        double attackBonus = 1.2;
        int defenseStat = 111;
        int min = Integer.MAX_VALUE;
        int max = Integer.MIN_VALUE;
        for (int i = 0; i < 1000000; i++) {
            int dmg = PokemonBattler.damage(attackStat, attackPower,
                                            attackBonus, defenseStat);
            if (dmg < min) {
                min = dmg;
            }
            if (dmg > max) {
                max = dmg;
            }
        }
        assertEquals(min, 42);
    }

    @Test
    void testDamage2of4() {
        // information about attacker and defender
        int attackStat = 112;
        int attackPower = 80;
        double attackBonus = 1.2;
        int defenseStat = 111;
        int min = Integer.MAX_VALUE;
        int max = Integer.MIN_VALUE;
        for (int i = 0; i < 1000000; i++) {
            int dmg = PokemonBattler.damage(attackStat, attackPower,
                                            attackBonus, defenseStat);
            if (dmg < min) {
                min = dmg;
            }
            if (dmg > max) {
                max = dmg;
            }
        }
        assertEquals(max, 49);
    }

    @Test
    void testDamage3of4() {
        // information about attacker and defender
        int attackStat = 225;
        int attackPower = 100;
        double attackBonus = 1.2;
        int defenseStat = 182;
        int min = Integer.MAX_VALUE;
        int max = Integer.MIN_VALUE;
        for (int i = 0; i < 1000000; i++) {
            int dmg = PokemonBattler.damage(attackStat, attackPower,
                                            attackBonus, defenseStat);
            if (dmg < min) {
                min = dmg;
            }
            if (dmg > max) {
                max = dmg;
            }
        }
        assertEquals(min, 64);
    }

    @Test
    void testDamage4of4() {
        // information about attacker and defender
        int attackStat = 225;
        int attackPower = 100;
        double attackBonus = 1.2;
        int defenseStat = 182;
        int min = Integer.MAX_VALUE;
        int max = Integer.MIN_VALUE;
        for (int i = 0; i < 1000000; i++) {
            int dmg = PokemonBattler.damage(attackStat, attackPower,
                                            attackBonus, defenseStat);
            if (dmg < min) {
                min = dmg;
            }
            if (dmg > max) {
                max = dmg;
            }
        }
        assertEquals(max, 75);
    }

    private String getExpectedDefenderOutput(String attacker, String defender) {
        return "Which pokemon do you choose? " +
               "You chose " + defender + "!\n" +
               "It's a pokemon battle between " + 
               attacker + " and " + defender + "!";
    }

    private String getExpectedDefenseStatOutput(String defender) {
        return "Trainer, enter the defense stat for " +
               "your " + defender + ".\nDefense:";
    }

}
