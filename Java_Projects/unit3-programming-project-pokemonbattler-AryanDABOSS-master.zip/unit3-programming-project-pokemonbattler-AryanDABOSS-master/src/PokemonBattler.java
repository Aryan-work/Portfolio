//////////////////////////////////////////////////////////////////////////////
//
// AP CS A
// Unit 3.1 Lesson 7 
// Programming Project
//
// Pokemon Battler
//
// written by {Aryan}
//
import java.util.Scanner;

public class PokemonBattler {

    public static void main(String[] args) {
        // information about the attacker (Pikachu)
        // https://db.pokemongohub.net/pokemon/25
        
    	String attacker = "Pikachu";
        int attackStat = 112;
        
        // information about the charged move (Thunderbolt)
        // https://db.pokemongohub.net/moves/79
       
        String attackMove = "Thunderbolt";
        int attackPower = 80;
        double attackBonus = 1.2;

        // announced the challenge
        System.out.println("Another trainer is issuing a challenge!");
        System.out.println(attacker + " appeared.");

        // I created a scanner object
        
        Scanner console = new Scanner(System.in);
        
        // I called the getDefender() method and assigned the return
        // value to a String variable named "defender".  The method
        // required two parameters: a Scanner object and a String
        // that represented the name of the attacking pokemon
        
        String defender= getDefender(console, attacker);
        
        // I called the getDefenseStat() method and assigned the return
        // value to an integer variable named "defenseStat".  The method
        // required two parameters: a Scanner object and a String
        // that represented the name of the defending pokemon
        
        int defenseStat = getDefenseStat(console, defender);
        
        // announced the attack
        
        System.out.println(attacker + " uses " + attackMove + "!");
        
        // I called the damage() method, captured the return value,
        // and printed the result to the console in the following format:
        // "{ defender } takes { amount } damage."
        
        int damage = damage(attackStat, attackPower, attackBonus, defenseStat);
        System.out.println(defender +" takes "+ damage + " damamge.");
        
        // I closed the scanner object
        console.close();
    }

    // I wrote a method named it getDefender() that accepted a Scanner
    // object and a String.  The Scanner object was used to capture
    // user input and the String represented the attacking pokemon.  In
    // the method, I prompted the user for the name of the pokemon defender.
    // Used the Scanner object to capture the input.  Then summarized the
    // choice and announced the battle.  The output EXACTLY matchs
    // the output as described in the project requirements document. The
    // method returned the name of the defending pokemon.
    
public static String getDefender(Scanner console, String attackpokemon) {
	System.out.print("Which pokemon do you choose? ");
	String userchoice = console.nextLine();
	System.out.println("You chose "+userchoice+"!");
	System.out.println("It's a pokemon battle between "+attackpokemon+" and "+userchoice+"!");
	return userchoice;
}

    // I wrote a method named getDefenseStat() that accepted a Scanner
    // object and a String.  The Scanner object was used to capture
    // user input and the String represented the defending pokemon.  In
    // the method, I prompted the user for the defense stat of the pokemon
    // defender and used the Scanner object to capture the input as an
    // integer value.  The output EXACTLY matches the prompt as
    // described in the project requirements document.  The method
    // returned the integer value of the defense stat.

public static int getDefenseStat (Scanner console, String defender) {
	System.out.print("Trainer, enter the defense stat for your "+defender+".\nDefense: ");
	int defensestat = console.nextInt();
	return defensestat;
} 

    // I wrote a method named damage() that accepted four parameters.
    // The first three parameters were the attack stat, attack power, and
    // attack bonus of the attacking pokemon.  The fourth parameter was the
    // defense stat of the defending pokemon.  The method calculated
    // the damage of the attack based on the formula provided in the
    // project requirements document.  Part of the formula required the
    // generation of a random floating point number from 0.85 to 0.99.

public static int damage(int attack, int power, double bonus, int defense) {
	double rando = Math.random() *(0.999-0.850)+0.850;
	int damage = (int)Math.floor(1*power*(attack)*bonus*rando/(2*defense))+1;
	return damage;
}

}
