import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class DateTest {

    @Test
    public void testParameterlessDataConstructor1of3() {
        Date d = new Date();
        assertEquals(1970, d.getYear());
    }

    @Test
    public void testParameterlessDataConstructor2of3() {
        Date d = new Date();
        assertEquals(1, d.getMonth());
    }

    @Test
    public void testParameterlessDataConstructor3of3() {
        Date d = new Date();
        assertEquals(1, d.getDay());
    }

    @Test
    public void testThreeParameterDateContructor1of15() {
        Date d = new Date(1995, 10, 8);
        assertEquals(1995, d.getYear());
    }

    @Test
    public void testThreeParameterDateContructor2of15() {
        Date d = new Date(1995, 10, 8);
        assertEquals(10, d.getMonth());
    }

    @Test
    public void testThreeParameterDateContructor3of15() {
        Date d = new Date(1995, 10, 8);
        assertEquals(8, d.getDay());
    }

    @Test
    public void testThreeParameterDateContructor4of15() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            Date d = new Date(1995, 0, 8);
        });
    }

    @Test
    public void testThreeParameterDateContructor5of15() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            Date d = new Date(1995, -1, 8);
        });
    }

    @Test
    public void testThreeParameterDateContructor6of15() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            Date d = new Date(1995, 10, 0);
        });
    }

    @Test
    public void testThreeParameterDateContructor7of15() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            Date d = new Date(1995, 10, -1);
        });
    }

    @Test
    public void testThreeParameterDateContructor8of15() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            Date d = new Date(-1, 10, 8);
        });
    }

    @Test
    public void testThreeParameterDateContructor9of15() {
        Date d = new Date(0, 10, 8);
        assertEquals(0, d.getYear());
    }

    @Test
    public void testThreeParameterDateContructor10of15() {
        Date d = new Date(1999, 12, 62);
        assertEquals(2000, d.getYear());
    }

    @Test
    public void testThreeParameterDateContructor11of15() {
        Date d = new Date(1999, 12, 62);
        assertEquals(1, d.getMonth());
    }

    @Test
    public void testThreeParameterDateContructor12of15() {
        Date d = new Date(1999, 12, 62);
        assertEquals(31, d.getDay());
    }

    @Test
    public void testThreeParameterDateContructor13of15() {
        Date d = new Date(1998, 100, 115);
        assertEquals(2006, d.getYear());
    }

    @Test
    public void testThreeParameterDateContructor14of15() {
        Date d = new Date(1998, 100, 115);
        assertEquals(7, d.getMonth());
    }

    @Test
    public void testThreeParameterDateContructor15of15() {
        Date d = new Date(1998, 100, 115);
        assertEquals(24, d.getDay());
    }

    @Test
    public void testCloneDateConstructor1of3() {
        Date d1 = new Date(1995, 10, 8);
        Date d2 = new Date(d1);
        assertEquals(1995, d2.getYear());
    }

    @Test
    public void testCloneDateConstructor2of3() {
        Date d1 = new Date(1995, 10, 8);
        Date d2 = new Date(d1);
        assertEquals(10, d2.getMonth());
    }

    @Test
    public void testCloneDateConstructor3of3() {
        Date d1 = new Date(1995, 10, 8);
        Date d2 = new Date(d1);
        assertEquals(8, d2.getDay());
    }

    @Test
    public void testGetYear() {
        Date d = new Date(2014, 2, 2);
        assertEquals(2014, d.getYear());
    }

    @Test
    public void testGetMonth() {
        Date d = new Date(2015, 1, 18);
        assertEquals(1, d.getMonth());
    }

    @Test
    public void testGetDay() {
        Date d = new Date(2015, 1, 18);
        assertEquals(18, d.getDay());
    }

    @Test
    public void testIsLeapYear1of3() {
        Date d = new Date();
        assertEquals(false, d.isLeapYear());
    }

    @Test
    public void testIsLeapYear2of3() {
        Date d = new Date(1900, 1, 1);
        assertEquals(false, d.isLeapYear());
    }

    @Test
    public void testIsLeapYear3of3() {
        Date d = new Date(2000, 1, 1);
        assertEquals(true, d.isLeapYear());
    }

    @Test
    public void testAddDays1of4() {
        Date d = new Date();
        d.addDays(30);
        assertEquals("1970/01/31", d.toString());
    }

    @Test
    public void testAddDays2of4() {
        Date d = new Date();
        d.addDays(31);
        assertEquals("1970/02/01", d.toString());
    }

    @Test
    public void testAddDays3of4() {
        Date d = new Date();
        d.addDays(365);
        assertEquals("1971/01/01", d.toString());
    }

    @Test
    public void testAddDays4of4() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            Date d = new Date(2006, 7, 29);
            d.addDays(-1);
        });
    }

    @Test
    public void testAddWeeks() {
        Date d = new Date();
        d.addWeeks(52);
        assertEquals("1970/12/31", d.toString());
    }

    @Test
    public void testDaysTo1of9() {
        Date d1 = new Date(1970, 1, 1);
        Date d2 = new Date(1970, 1, 2);
        assertEquals(1, d1.daysTo(d2));
    }

    @Test
    public void testDaysTo2of9() {
        Date d1 = new Date(1970, 1, 31);
        Date d2 = new Date(1970, 2, 1);
        assertEquals(1, d1.daysTo(d2));
    }

    @Test
    public void testDaysTo3of9() {
        Date d1 = new Date(1969, 12, 31);
        Date d2 = new Date(1970, 1, 1);
        assertEquals(1, d1.daysTo(d2));
    }

    @Test
    public void testDaysTo4of9() {
        Date d1 = new Date(2014, 2, 2);
        Date d2 = new Date(2020, 2, 2);
        int days = d1.daysTo(d2);
        assertEquals(2191, days);
    }

    @Test
    public void testDaysTo5of9() {
        Date d1 = new Date(2014, 2, 2);
        Date d2 = new Date(2020, 2, 2);
        int days = d1.daysTo(d2);
        Date d3 = new Date(2014, 2, 2);
        assertTrue(d1.equals(d3));
    }

    @Test
    public void testDaysTo6of9() {
        Date d1 = new Date(2014, 2, 2);
        Date d2 = new Date(2020, 2, 2);
        int days = d2.daysTo(d1);
        assertEquals(-2191, days);
    }

    @Test
    public void testDaysTo7of9() {
        Date d1 = new Date(1969, 12, 31);
        Date d2 = new Date(1970, 1, 1);
        assertEquals(-1, d2.daysTo(d1));
    }

    @Test
    public void testDaysTo8of9() {
        Date d1 = new Date(1970, 1, 31);
        Date d2 = new Date(1970, 2, 1);
        assertEquals(-1, d2.daysTo(d1));
    }

    @Test
    public void testDaysTo9of9() {
        Date d1 = new Date(1970, 1, 1);
        Date d2 = new Date(1970, 1, 2);
        assertEquals(-1, d2.daysTo(d1));
    }

    @Test
    public void testCompareTo1of5() {
        Date d1 = new Date(2000, 1, 1);
        Date d2 = new Date(2000, 1, 1);
        assertEquals(0, d1.compareTo(d2));
    }

    @Test
    public void testCompareTo2of5() {
        Date d1 = new Date(1999, 12, 31);
        Date d2 = new Date(2000, 1, 1);
        assertTrue(d1.compareTo(d2) < 0);
    }

    @Test
    public void testCompareTo3of5() {
        Date d1 = new Date(1999, 12, 31);
        Date d2 = new Date(2000, 1, 1);
        assertTrue(d2.compareTo(d1) > 0);
    }

    @Test
    public void testCompareTo4of5() {
        Date d1 = new Date(2000, 1, 1);
        Date d2 = new Date(2000, 1, 2);
        assertTrue(d1.compareTo(d2) < 0);
    }

    @Test
    public void testCompareTo5of5() {
        Date d1 = new Date(2000, 1, 1);
        Date d2 = new Date(2000, 2, 1);
        assertTrue(d1.compareTo(d2) < 0);
    }

    @Test
    public void testEqualsDate1of6() {
        Date d1 = new Date(2002, 7, 29);
        Date d2 = new Date(2002, 7, 29);
        assertEquals(true, d1.equals(d2));
    }

    public void testEqualsDate2of6() {
        Date d1 = new Date(2002, 7, 29);
        Date d2 = new Date(2002, 7, 30);
        assertEquals(false, d1.equals(d2));
    }

    public void testEqualsDate3of6() {
        Date d1 = new Date(2002, 7, 29);
        Date d2 = new Date(2002, 8, 29);
        assertEquals(false, d1.equals(d2));
    }

    public void testEqualsDate4of6() {
        Date d1 = new Date(2002, 7, 29);
        Date d2 = new Date(2003, 7, 29);
        assertEquals(false, d1.equals(d2));
    }

    @Test
    public void testEqualsDate5of6() {
        Date d1 = new Date();
        Date d2 = new Date(1970, 1, 1);
        assertEquals(true, d1.equals(d2));
    }

    @Test
    public void testEqualsDate6of6() {
        Date d1 = new Date(2014, 2, 2);
        Date d2 = new Date(2020, 2, 2);
        d1.addDays(d1.daysTo(d2));
        assertEquals(true, d1.equals(d2));
    }

    @Test
    public void testToString1of3() {
        Date d = new Date();
        assertEquals("1970/01/01", d.toString());
    }

    @Test
    public void testToString2of3() {
        Date d = new Date(2006, 7, 29);
        assertEquals("2006/07/29", d.toString());
    }

    @Test
    public void testToString3of3() {
        Date d = new Date(1945, 10, 2);
        assertEquals("1945/10/02", d.toString());
    }

    @Test
    public void testStaticIsLeapYear1of4() {
        assertEquals(false, Date.isLeapYear(1990));
    }

    @Test
    public void testStaticIsLeapYear2of4() {
        assertEquals(false, Date.isLeapYear(2100));
    }

    @Test
    public void testStaticIsLeapYear3of4() {
        assertEquals(true, Date.isLeapYear(2000));
    }

    @Test
    public void testStaticIsLeapYear4of4() {
        assertEquals(false, Date.isLeapYear(2021));
    }

    @Test
    public void testDaysInMonth1of3() {
        assertEquals(29, Date.daysInMonth(2020, 2));
    }

    @Test
    public void testDaysInMonth2of3() {
        assertEquals(31, Date.daysInMonth(2020, 1));
    }

    @Test
    public void testDaysInMonth3of3() {
        assertEquals(28, Date.daysInMonth(2019, 2));
    }

    @Test
    public void testDaysInYear1of3() {
        assertEquals(365, Date.daysInYear(1990));
    }

    @Test
    public void testDaysInYear2of3() {
        assertEquals(365, Date.daysInYear(2100));
    }

    @Test
    public void testDaysInYear3of3() {
        assertEquals(366, Date.daysInYear(2000));
    }

}
