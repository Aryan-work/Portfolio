
public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Date d1 = new Date();
		 d1.addWeeks(52);
	     System.out.println(d1);
	     
	}

}
