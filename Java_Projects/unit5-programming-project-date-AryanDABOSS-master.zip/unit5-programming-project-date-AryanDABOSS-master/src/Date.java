public class Date {
	
    ///////////////////////////////////////////////////////////////////
    //
    // private fields
    //
	private int _year;
	private int _month;
	private int _day;
	
    ///////////////////////////////////////////////////////////////////
    //
    // constructors
    //
	public Date (int year, int month, int day) {
		this.setYear(year);
		this.setMonth(month);
		this.setDay(day);
	}
	
	public Date () {
		this (1970, 1, 1);
	}
	
	public Date (Date d) {
		this (d.getYear(), d.getMonth(), d.getDay());
	}
	
    ///////////////////////////////////////////////////////////////////
    //
    // "getter" methods
    //
	public int getYear () {
		return this._year;
	}
	
	public int getMonth () {
		return this._month;
	}
	
	public int getDay () {
		return this._day;
	}
	
    ///////////////////////////////////////////////////////////////////
    //
    // private "setter" methods (see specification for details)
    //
	private void setDay (int day) {
		if (day <= 0) {
			throw new IllegalArgumentException();
		}
		while (day > daysInMonth(this.getYear(), this.getMonth())) {
			day -= daysInMonth(this.getYear(), this.getMonth());
			this.setMonth(this.getMonth() + 1);
		}
		this._day = day;
	}
	
	private void setMonth (int month) {
		if (month <= 0) {
			throw new IllegalArgumentException();
		}
		while (month > 12) {
			month -= 12;
			this.setYear(this.getYear() + 1);
		}
		this._month = month;	
	}
	
	private void setYear (int year) {
		if (year < 0) {
			throw new IllegalArgumentException();
		}
		this._year = year;
	}
	
    ///////////////////////////////////////////////////////////////////
    //
    // instance methods
    //
	public boolean isLeapYear() {
		return Date.isLeapYear(this.getYear());
	}
	
	public String toString() {
		String result = "";
		if(this._day < 10  || this._month < 10) {
			if (this._day < 10  && this._month < 10) {
				result = this._year + "/0" + this._month + "/0" + this._day;
				return result;
			}
			else if (this._day < 10) {
				result = this._year + "/" + this._month + "/0" + this._day;
				return result;
			}
			else if (this._month < 10) {
				result = this._year + "/0" + this._month + "/" + this._day;
				return result;
			}
		}
		else {
			result = this._year + "/" + this._month + "/" + this._day; 
			return result;
		}
		return result;
	}
	
	public void addDays(int days) {
		if (days < 0) {
			throw new IllegalArgumentException();
		}
		int result = this.getDay() + days;
		this.setDay(result);
	}

	public void addWeeks(int weeks) {
		this.addDays(weeks*7);
	}
	
	public int compareTo(Date other) {
		if (this.getDay() == other.getDay() && this.getMonth() == other.getMonth() && this.getYear() == other.getYear()) {
			return 0;
		}
		else {
			if(this.getYear() > other.getYear()) {
				return 1;
			}
			else if(this.getYear() == other.getYear() && this.getMonth() > other.getMonth()) {
				return 1;
			}
			else if (this.getDay() > other.getDay() && this.getMonth() == other.getMonth() && this.getYear() == other.getYear()) {
				return 1;
			}
			else {
				return -1;
			}
			
		}
	}
	
	public boolean equals(Date other) {
		if (this.getDay() == other.getDay() && this.getMonth() == other.getMonth() && this.getYear() == other.getYear()) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public int daysTo(Date other) {
		int day = this.getDay();
		int month = this.getMonth();
		int year = this.getYear();
		int count = 0;
		if (this.compareTo(other) == 0) {
			return 0;
		}
		else if (this.compareTo(other) > 0) {
			while (!other.equals(this)) {
				other.addDays(1);
				count ++; 
			}
			this.setDay(day);
			this.setMonth(month);
			this.setYear(year);
			return count * -1;
		}
		else {
			while (!this.equals(other)) {
				this.addDays(1);
				count ++; 
			}
			this.setDay(day);
			this.setMonth(month);
			this.setYear(year);
			return count;
		}		
	}
	
    ///////////////////////////////////////////////////////////////////
    //
    // static methods
    //
	public static boolean isLeapYear(int year) {
		if(year % 4 == 0) {
			if(year % 100 == 0){
				if(year % 400 == 0) {
					return true;
				}
				else {
					return false;
				}
			}
			else {
				return true;
			}
		}
		else {
			return false;
		}
	}
	
	public static int daysInMonth(int year, int month) {
		int [] days = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
		if (isLeapYear(year) == true && month == 2) {
				return 29;
		}
		else {
			return days[month-1];
		}
	}
	
	public static int daysInYear(int year) {
		if (isLeapYear(year) == true) {
			return 366;
		}
		else {
			return 365;
		}
	}
	
}