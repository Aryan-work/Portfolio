import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class EquestriaTest {
	//Tests the roundtrip method by comparing actual value with expected value
	@Test
	void testRoundTrip() {
		double actual = Equestria.roundTrip(1);
		double expected = 3.1415;
		assertEquals(expected, actual, 0.005);
	}
	//Tests the distance method by comparing actual value with expected value
	@Test
	void testDistance() {
		double actual = Equestria.distance(0, 0, 3, 4);
		double expected = 5.0;
		assertEquals(expected, actual, 0.005);
	}
	//Tests the totalTrip method by comparing actual value with expected value
	@Test
	void testTotalTrip() {
		double actual = Equestria.totalTrip(0, 0, 1, 1, 2, 2);
		double expected = 5.66;
		assertEquals(expected, actual, 0.005);
	}

}
