//////////////////////////////////////////////////////////////////////////////
//
// AP CS A
// Unit 3.1 Lesson 4 
// Programming Project
//
// Equestria
//
// written by {Aryan Sharma}
//

public class Equestria {
    
    public static void main(String[] args) {

        // call the roundTrip() method, capture the return value,
        // and print the result to the console according to the format 
        // as defined in the project requirements document. 
    	int x = 3;
    	System.out.printf("The trip distance for a circular route with a diameter of %d = %.2f\n", x, roundTrip(x) );
        // call the distance() method, capture the return value,
        // and print the result to the console according to the format 
        // as defined in the project requirements document. 
    	double d = distance(29, 16, 34, 8);
    	System.out.printf("Distance from Baltimare (29,16) to Manehattan (34,8) = %.2f\n", d);
        // call the totalTrip() method, capture the return value,
        // and print the result to the console according to the format 
        // as defined in the project requirements document. 
    	System.out.printf("Distance from (0,0) to (1, 1) to (2, 2) and back to (0,0) = %.2f\n", totalTrip(0, 0, 1, 1, 2, 2));
    }

    // Exercise 1. I wrote a method named roundTrip() that will 
    // accept the diameter of a circular path as a parameter; calculate
    // the distance of the circular route; and return the length of the
    // trip with floating point precision.
    public static double roundTrip (int diameter) {
    	return Math.PI*diameter;
    }
    // Exercise 2. I wrote a method named distance() that will 
    // accept four integer coordinates [ x1, y1, x2, y2 ] as parameters;
    // compute the distance between the two points as represented by the
    // Cartesian coordinates (x1, y1) and (x2, y2) on the map; and 
    // return that calculated distance with floating point precision.
    public static double distance(int x1, int y1, int x2, int y2) {
    	return Math.sqrt(Math.pow(x2-x1, 2) + Math.pow(y2-y1, 2));
    }
    // Exercise 3. I wrote a method named totalTrip() that will 
    // accept the x and y coordinates of three locations; compute  the 
    // total distance traveled by visiting all 3 locations and returning
    // to the starting location; then return that calculated distance 
    // with floating point precision. The implementation of this method
    // should utilize the distance() method from Exercise 2.
    public static double totalTrip(int x1, int y1, int x2, int y2, int x3, int y3) {
    	double trip1 = distance(x1, y1, x2, y2);
    	double trip2 = distance(x2, y2, x3, y3);
    	double trip3 = distance(x3, y3, x1, y1);
    	return trip1+trip2+trip3;
    }
}
