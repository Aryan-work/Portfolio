
public class Cone extends Shape3D{

	private double _radius;
	private double _height;
	
	public Cone (double r, double h) {
		this._radius = r;
		this._height = h;
	}
	
	public double getRadius () {
		return this._radius;
	}
	
	public double getHeight() {
		return this._height;
	}
	
	@Override
	public double getSurfaceArea() {
		return Math.PI * this.getRadius() * (this.getRadius() + 
				Math.pow(Math.pow(this.getRadius(), 2) + Math.pow(this.getHeight(), 2), 0.5));
	}

	@Override
	public double getVolume() {
		return (Math.PI * Math.pow(this.getRadius(), 2) * this.getHeight()) / 3.0;
	}
	
}
