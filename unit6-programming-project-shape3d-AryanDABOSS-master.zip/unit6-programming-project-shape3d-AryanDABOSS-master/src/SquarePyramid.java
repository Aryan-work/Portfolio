
public class SquarePyramid extends RectangularPyramid {
	private double _length;
	private double _height;
	private double _width;
	
	public SquarePyramid (double s, double h) {
		super (s, s, h);
		this._length = s;
		this._height = h;
		this._width = s;
	}
	
	public double getLength () {
		return this._length;
	}
	
	public double getHeight() {
		return this._height;
	}

}
