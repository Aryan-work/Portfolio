
public class RectangularPyramid extends Shape3D{
	
	private double _length;
	private double _height;
	private double _width;
	
	public RectangularPyramid (double l, double w, double h) {
		this._length = l;
		this._height = h;
		this._width = w;
	}
	
	public double getLength () {
		return this._length;
	}
	
	public double getHeight() {
		return this._height;
	}
	
	public double getWidth () {
		return this._width;
	}
	
	@Override
	public double getSurfaceArea() {
		return (this.getLength() * this.getWidth()) + (this.getLength() * 
				(Math.pow(Math.pow(this.getWidth() / 2.0, 2) + Math.pow(this.getHeight(), 2), 0.5))) + 
				(this.getWidth() * (Math.pow(Math.pow(this.getLength() / 2, 2) + Math.pow(this.getHeight(), 2), 0.5)));
	}

	@Override
	public double getVolume() {
		return (this.getLength() * this.getHeight() * this.getWidth()) / 3.0;
	}

	
}
