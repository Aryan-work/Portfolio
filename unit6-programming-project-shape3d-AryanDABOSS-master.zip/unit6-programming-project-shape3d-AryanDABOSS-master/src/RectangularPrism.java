
public class RectangularPrism extends Shape3D {
	private double _length;
	private double _height;
	private double _width;
	
	public RectangularPrism (double l, double h, double w) {
		this._length = l;
		this._height = h;
		this._width = w;
	}
	
	public double getLength () {
		return this._length;
	}
	
	public double getHeight() {
		return this._height;
	}
	
	public double getWidth () {
		return this._width;
	}
	
	@Override
	public double getSurfaceArea() {
		return 2 * (this.getHeight() * this.getLength() + this.getHeight() * this.getWidth() + this.getLength() * this.getWidth());
	}

	@Override
	public double getVolume() {
		return this.getLength() * this.getHeight() * this.getWidth();
	}
	
}
