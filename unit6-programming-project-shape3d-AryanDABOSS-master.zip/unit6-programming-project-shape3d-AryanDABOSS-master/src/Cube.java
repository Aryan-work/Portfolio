
public class Cube extends RectangularPrism {
	
	private double _length;
	private double _height;
	private double _width;
	
	public Cube (double s) {
		super (s, s, s);
		this._height = s;
		this._length = s;
		this._width = s;
	}
	
	public double getSide() {
		return this._length;
	}
	
}
