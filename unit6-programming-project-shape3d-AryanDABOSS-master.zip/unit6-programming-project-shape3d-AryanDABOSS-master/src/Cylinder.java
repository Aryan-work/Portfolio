
public class Cylinder extends Shape3D{

	private double _radius;
	private double _height;
	
	public Cylinder (double r, double h) {
		this._radius = r;
		this._height = h;
	}
	
	public double getRadius () {
		return this._radius;
	}
	
	public double getHeight() {
		return this._height;
	}
	
	@Override
	public double getSurfaceArea() {
		return 2 * Math.PI * this.getRadius() * this.getHeight() + 2 * Math.PI * Math.pow(this.getRadius(), 2);
	}

	@Override
	public double getVolume() {
		return Math.PI * Math.pow(this.getRadius(), 2) * this.getHeight();
	}
	
}
