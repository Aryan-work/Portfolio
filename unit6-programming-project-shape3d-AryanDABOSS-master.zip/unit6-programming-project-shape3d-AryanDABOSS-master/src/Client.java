
public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		RectangularPyramid rp = new RectangularPyramid(3.0, 4.0, 6.0);
		System.out.println(rp.getSurfaceArea());
		System.out.println(rp.getLength());
		System.out.println(rp.getHeight());
		System.out.println(rp.getWidth());
	}

}
