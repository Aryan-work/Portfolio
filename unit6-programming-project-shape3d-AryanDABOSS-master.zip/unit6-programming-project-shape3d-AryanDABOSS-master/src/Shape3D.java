// this abstract class represents any 3D shape that can be measured
// by volume and by surface area and compared to another by volume
public abstract class Shape3D implements Measurable3D, Comparable<Shape3D> {
 
    public abstract double getSurfaceArea();
    public abstract double getVolume();
    
    public int compareTo(Shape3D other) {
        double thisVolume = this.getVolume();
        double otherVolume = other.getVolume();
        if (thisVolume < otherVolume) {
            return -1;
        }
        else if (thisVolume > otherVolume) {
            return 1;
        }
        else {
            return 0;
        }
    } 
    
    public String toString() {
    	return "Shape3D";
    }
    
}
