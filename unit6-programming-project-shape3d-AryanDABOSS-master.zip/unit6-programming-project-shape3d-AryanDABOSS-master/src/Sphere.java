
public class Sphere extends Shape3D{
	private double _radius;
	
	public Sphere (double r) {
		this._radius = r;
	}
	
	public double getRadius () {
		return this._radius;
	}
	
	@Override
	public double getSurfaceArea() {
		return 4 * Math.PI * Math.pow(this.getRadius(), 2);
	}

	@Override
	public double getVolume() {
		return (Math.PI * Math.pow(this.getRadius(), 3)) * (4.0 / 3.0);
	}
	
}
