//////////////////////////////////////////////////////////////////////////////
//
// AP CS A
// Unit 2 Lesson 8 
// Programming Project
//
// HourGlass
//
// written by {Aryan Sharma}
//

public class HourGlass {
    
    //declared a class constant named 'SIZE'
    public static final int SIZE = 5;
    
    public static void line() {
    	System.out.print("|");
    	for(int i = 1; i<= 2*SIZE+2; i++) {
    		System.out.print("=");
    	}
    	System.out.print ("|"); 
    	System.out.println("");
    }
    
    public static void tophalf() {
    	for (int i = 0; i< SIZE; i++) {
    			for (int j = 0; j<=i; j++) {
    				System.out.print(" ");
    			}
    		System.out.print("\\");
    			for(int k = 1; k<=2*(SIZE-i); k++) {
    				System.out.print(" ");
    			}
    		System.out.println("/");
    	}
    }
    
    public static void middle() {
    	for(int i=0; i<SIZE+1; i++) {
    		System.out.print(" ");
    	}
    	System.out.println("||");
    }
    
    public static void bottomhalf() {
    	for (int i = 1; i<=SIZE; i++) {
    			for (int j = 0; j<SIZE-i+1; j++) {
    				System.out.print(" ");
    			}
    		System.out.print("/");
    			for(int k = 0; k<2*i; k++) {
    				System.out.print(":");
    			}
    		System.out.println("\\");
    	}
    }
    
    public static void main(String[] args) {
    	line();	
    	tophalf();
    	middle();
    	bottomhalf();
    	line();
    }
}
