import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import java.awt.Color;

public class SteganographyTestActivity1 {

    @Test
    public void testClearLow1of4() {
        // create a picture
        Picture test = new Picture("img/beach.jpg");
        // get an array of the pixels
        Pixel[][] pixels = test.getPixels2D();
        // clear the low bits for pixels[180][180]
        Pixel p = pixels[180][180];
        Steganography.clearLow(p);
        // run the test
        assertEquals(156, p.getRed());
    }

    @Test
    public void testClearLow2of4() {
        // create a picture
        Picture test = new Picture("img/beach.jpg");
        // get an array of the pixels
        Pixel[][] pixels = test.getPixels2D();
        // clear the low bits for pixels[180][180]
        Pixel p = pixels[180][180];
        Steganography.clearLow(p);
        // run the test
        assertEquals(180, p.getGreen());
    }

    @Test
    public void testClearLow3of4() {
        // create a picture
        Picture test = new Picture("img/beach.jpg");
        // get an array of the pixels
        Pixel[][] pixels = test.getPixels2D();
        // clear the low bits for pixels[180][180]
        Pixel p = pixels[180][180];
        Steganography.clearLow(p);
        // run the test
        assertEquals(168, p.getBlue());
    }

    @Test
    public void testClearLow4of4() {
        // create a picture
        Picture test = new Picture("img/beach.jpg");
        // get an array of the pixels
        Pixel[] pixels = test.getPixels();
        // pick a pixel at random
        int i = (int)(Math.random() * pixels.length);
        Pixel p = pixels[i];
        // run the test
        Steganography.clearLow(p);
        int sum = p.getRed() % 4 + p.getGreen() % 4 + p.getBlue() % 4;
        assertEquals(0, sum);
    }

    @Test
    public void testTestClearLow1of2() {
        // create a picture
        Picture test = new Picture("beach.jpg");
        // run the test
        Picture copy = Steganography.testClearLow(test);
        assertNotSame(test, copy);
    }

    @Test
    public void testTestClearLow2of2() {
        // create a picture
        Picture test = new Picture("beach.jpg");
        // build a copy of the picture whose pixels have all been "cleared"
        Picture copy = Steganography.testClearLow(test);
        // get an array of the pixels
        Pixel[] pixels = copy.getPixels();
        // run the test
        int sum = 0;
        for (Pixel p : pixels) {
            sum += p.getRed() % 4 + p.getGreen() % 4 + p.getBlue() % 4;
        }
        assertEquals(0, sum);
    }

    @Test
    public void testSetLow1of3() {
        // create a picture
        Picture test = new Picture("beach.jpg");
        // create a color
        Color c = new Color(65, 129, 193);
        // get an array of the pixels
        Pixel[] pixels = test.getPixels();
        // pick a pixel at random
        int i = (int)(Math.random() * pixels.length);
        Pixel p = pixels[i];
        // run the test
        Steganography.setLow(p, c);
        assertEquals(1, p.getRed() % 4);
    }

    @Test
    public void testSetLow2of3() {
        // create a picture
        Picture test = new Picture("beach.jpg");
        // create a color
        Color c = new Color(65, 129, 193);
        // get an array of the pixels
        Pixel[] pixels = test.getPixels();
        // pick a pixel at random
        int i = (int)(Math.random() * pixels.length);
        Pixel p = pixels[i];
        // run the test
        Steganography.setLow(p, c);
        assertEquals(2, p.getGreen() % 4);
    }

    @Test
    public void testSetLow3of3() {
        // create a picture
        Picture test = new Picture("beach.jpg");
        // create a color
        Color c = new Color(65, 129, 193);
        // get an array of the pixels
        Pixel[] pixels = test.getPixels();
        // pick a pixel at random
        int i = (int)(Math.random() * pixels.length);
        Pixel p = pixels[i];
        // run the test
        Steganography.setLow(p, c);
        assertEquals(3, p.getBlue() % 4);
    }

    @Test
    public void testTestSetLow1of3() {
        // create a picture
        Picture test = new Picture("beach.jpg");
        // run the test
        Picture copy = Steganography.testSetLow(test, new Color(0, 0, 0));
        assertNotSame(test, copy);
    }

    @Test
    public void testTestSetLow2of3() {
        // create a picture
        Picture test = new Picture("beach.jpg");
        // build a copy of the picture whose pixels have all been set to a color
        Color c = new Color(65, 129, 193);
        Picture copy = Steganography.testSetLow(test, c);
        // get an array of the pixels
        Pixel[] pixels = copy.getPixels();
        // run the test
        int sum = 0;
        for (Pixel p : pixels) {
            sum += p.getRed() % 4 + p.getGreen() % 4 + p.getBlue() % 4;
        }
        int expected = 6 * pixels.length;
        assertEquals(expected, sum);
    }

    @Test
    public void testTestSetLow3of3() {
        // create a picture
        Picture test = new Picture("beach.jpg");
        // build an expected sum of pixel values
        Pixel[] pixelsTest = test.getPixels();
        int expectedSum = 0;
        for (Pixel p : pixelsTest) {
            expectedSum += p.getRed() / 4 + p.getGreen() / 4 + p.getBlue() / 4;
        }
        // build a copy of the picture whose pixels have all been set to a color
        Color c = new Color(65, 129, 193);
        Picture copy = Steganography.testSetLow(test, c);
        // get an array of the pixels
        Pixel[] pixelsCopy = copy.getPixels();
        // run the test
        int sumCopy = 0;
        for (Pixel p : pixelsCopy) {
            sumCopy += p.getRed() / 4 + p.getGreen() / 4 + p.getBlue() / 4;
        }
        assertEquals(expectedSum, sumCopy);
    }

    @Test
    public void testRevealPicture1of3() {
        // create a picture
        Picture test = new Picture("beach.jpg");
        // run the test
        Picture copy = Steganography.revealPicture(test);
        assertNotSame(test, copy);
    }

    @Test
    public void testRevealPicture2of3() {
        // create a picture
        Picture test = new Picture("beach.jpg");
        // build a copy of the picture whose pixels have all been set to a color
        Color c = new Color(65, 129, 193);
        Picture copy = Steganography.testSetLow(test, c);
        // run the test
        Picture reveal = Steganography.revealPicture(copy);
        Pixel[] pixels = reveal.getPixels();
        int sum = 0;
        for (Pixel p : pixels) {
            sum += p.getRed() % 64 + p.getGreen() % 64 + p.getBlue() % 64;
        }
        int expected = 0;
        assertEquals(expected, sum);
    }

    @Test
    public void testRevealPicture3of3() {
        // create a picture
        Picture test = new Picture("beach.jpg");
        // build a copy of the picture whose pixels have all been set to a color
        Color c = new Color(65, 129, 193);
        Picture copy = Steganography.testSetLow(test, c);
        // run the test
        Picture reveal = Steganography.revealPicture(copy);
        Pixel[] pixels = reveal.getPixels();
        int sum = 0;
        for (Pixel p : pixels) {
            sum += p.getRed() / 64 + p.getGreen() / 64 + p.getBlue() / 64;
        }
        int expected = 6 * pixels.length;
        assertEquals(expected, sum);
    }

}
