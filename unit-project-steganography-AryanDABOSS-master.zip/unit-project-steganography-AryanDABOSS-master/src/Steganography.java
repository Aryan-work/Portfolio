import java.awt.Color;
import java.util.ArrayList;

public class Steganography {

    ////////////////////////////////////////////////////////////////////
    //
    // main() method
    //
    // The main method contains the client code for each of the four
    // activities.  The client code is separated into sections.  It is
    // recommended that you only uncomment one section of the client
    // code at a time.
    //
    // For example, when you begin working on Activity 1, uncomment the
    // client code for Activity 1 only.  After you have completed the
    // code for Activity 1 (and all tests pass), then comment out the
    // client code for Activity 1 and uncomment the client code for
    // Activity 2.  Repeat this process as you work on each respective
    // activity in the student guide.
    //
    // Each activity will require that you complete the "TODO" tasks
    // that are contained in the code below the main() method.
    //
    public static void main(String[] args) {

        ////////////////////////////////////////////////////////////////
        // ACTIVITY 1 Client Code: Exploring Color
    	
        
        // Exercise 1.8
        Picture beach1dot8 = new Picture("img/beach.jpg");
        beach1dot8.setTitle("1.8 Beach Original");
        beach1dot8.explore();
        Picture copy1dot8 = testClearLow(beach1dot8);
        copy1dot8.setTitle("1.8 Beach after testClearLow");
        copy1dot8.explore();
        
        
        // Exercise 1.12
        Picture beach1dot12 = new Picture("img/beach.jpg");
        beach1dot12.setTitle("1.12 Beach Original");
        beach1dot12.explore();
        Color eastlakeRed = new Color(107, 0, 36);
        Picture copy1dot12 = testSetLow(beach1dot12, eastlakeRed);
        copy1dot12.setTitle("1.12 Beach after testSetLow");
        copy1dot12.explore();

        // Exercise 1.14
        Picture copy1dot14 = revealPicture(copy1dot12);
        copy1dot14.setTitle("1.14 revealPicture");
        copy1dot14.explore();
        

        ////////////////////////////////////////////////////////////////
        // ACTIVITY 2 Client Code: Hiding and Revealing a Picture

        
        // Exercise 2.8
        Picture beach2dot8 = new Picture("img/beach.jpg");
        Picture arch2dot8 = new Picture("img/arch.jpg");
        System.out.println("beach same size as arch? " + canHide(beach2dot8, arch2dot8));
        
        // Exercise 2.9
        Picture swan2dot9 = new Picture("img/swan.jpg");
        Picture gorge2dot9 = new Picture("img/gorge.jpg");
        System.out.println("swan same size as gorge? " + canHide(swan2dot9, gorge2dot9));
        swan2dot9.setTitle("2.9 Swan Original");
        swan2dot9.explore();
        gorge2dot9.setTitle("2.9 Gorge Original");
        gorge2dot9.explore();
        Picture combined2dot9 = null;
        if (canHide(swan2dot9, gorge2dot9)) {
            combined2dot9 = hidePicture(swan2dot9, gorge2dot9);
            combined2dot9.setTitle("2.9 Gorge hidden in Swan");
            combined2dot9.explore();
        }

        // Exercise 2.11
        if (combined2dot9 != null) {
            Picture revealed2dot11 = revealPicture(combined2dot9);
            revealed2dot11.setTitle("2.11 Gorge revealed");
            revealed2dot11.explore();
        }
        
        
        ////////////////////////////////////////////////////////////////
        // ACTIVITY 3 Client Code: Identifying a Hidden Picture

        
        // Exercise 3.1
        Picture beach3dot1 = new Picture("img/beach.jpg");
        beach3dot1.setTitle("3.1 Beach Original");
        beach3dot1.explore();
        // hide the robot and flower pictures in the beach picture
        Picture robot3dot1 = new Picture("img/robot.jpg");
        Picture flower3dot1 = new Picture("img/flower1.jpg");
        if (canHide(beach3dot1, robot3dot1, 65, 208) && canHide(beach3dot1, flower3dot1, 280, 110)) {
            Picture temp = hidePicture(beach3dot1, robot3dot1, 65, 208);
            Picture hidden = hidePicture(temp, flower3dot1, 280, 110);
            hidden.setTitle("3.1 Beach with Hidden Pictures");
            hidden.explore();
            Picture unhidden = revealPicture(hidden);
            unhidden.setTitle("3.1 Beach with Revealed Pictures");
            unhidden.explore();
        }

        // Exercise 3.2
        Picture swanCopy1 = new Picture("img/swan.jpg");
        Picture swanCopy2 = new Picture("img/swan.jpg");
        System.out.print("Swan1 and swan2 are the same? ");
        System.out.println(isSame(swanCopy1, swanCopy2));
        swanCopy2 = testClearLow(swanCopy2);
        System.out.print("Swans are the same after clearLow on swan2? ");
        System.out.println(isSame(swanCopy1, swanCopy2));

        // Exercise 3.3
        Picture archCopy1 = new Picture("img/arch.jpg");
        Picture archCopy2 = new Picture("img/arch.jpg");
        Picture koala3dot3 = new Picture("img/koala.jpg");
        Picture robot3dot3 = new Picture("img/robot.jpg");
        ArrayList<Point> list33 = findDifferences(archCopy1, archCopy2);
        System.out.print("Number of pixels different between arch and arch: ");
        System.out.println(list33.size());
        list33 = findDifferences(archCopy1, koala3dot3);
        System.out.print("Number of pixels different between arch and koala: ");
        System.out.println(list33.size());
        archCopy2 = hidePicture(archCopy1, robot3dot3, 65, 102);
        list33 = findDifferences(archCopy1, archCopy2);
        System.out.print("Number of pixels different between arch with hidden ");
        System.out.print("image and original arch image: ");
        System.out.println(list33.size());
        archCopy1.setTitle("3.3 Original Arch");
        archCopy1.explore();
        archCopy2.setTitle("3.3 Arch with Hidden Image");
        archCopy2.explore();
        Picture revealed3dot3 = revealPicture(archCopy2);
        revealed3dot3.setTitle("3.3 Revealed Hidden Picture");
        revealed3dot3.explore();

        // Exercise 3.4
        Picture templeCopy1 = new Picture("img/femaleLionAndHall.jpg");
        Picture robot3dot4 = new Picture("img/robot.jpg");
        Picture flower3dot4 = new Picture("img/flower1.jpg");
        // hide pictures
        Picture templeCopy2 = hidePicture(templeCopy1, robot3dot4, 50, 300);
        Picture templeCopy3 = hidePicture(templeCopy2, flower3dot4, 115, 275);
        templeCopy3.setTitle("3.4 Original Female Lion and Hall");
        templeCopy3.explore();
        if (!isSame(templeCopy1, templeCopy3)) {
            ArrayList<Point> list34 = findDifferences(templeCopy1, templeCopy3);
            System.out.print("Number of pixels different between temple with hidden ");
            System.out.print("images and original arch image: ");
            System.out.println(list34.size());
            Picture templeCopy4 = showDifferentArea(templeCopy1, list34);
            templeCopy4.setTitle("3.4 Show Different Area");
            templeCopy4.explore();
            Picture unhidden = revealPicture(templeCopy3);
            unhidden.setTitle("3.4 Temple with Hidden Pictures");
            unhidden.explore();
        }
        

        ////////////////////////////////////////////////////////////////
        // ACTIVITY 4 Client Code: Hiding and Revealing a Text Message

        
        // Exercise 4.4
        Picture beach4dot4 = new Picture("img/beach.jpg");
        beach4dot4.setTitle("4.4 Original Beach Image");
        beach4dot4.explore();
        Picture hiddenText = hideText(beach4dot4, "Have fun storming the castle");
        hiddenText.setTitle("4.4 Beach Image with Hidden Text");
        hiddenText.explore();
        String secret = revealText(hiddenText);
        if (secret.equals("Have fun storming the castle")) {
            System.out.println("If only you had a wheelbarrow. (Success!)");
        }
        else {
            System.out.println("Do you think it worked? (It didn't.)");
        }
        

        ////////////////////////////////////////////////////////////////
    }

    ////////////////////////////////////////////////////////////////////
    //
    // ACTIVITY 1 Methods: Exploring Color
    //

    //////////////////////////////////////////////////
    // Changing Colors (Exercise 1.6-1.8)

    // clear the lower (rightmost) two bits of each RGB in a pixel
    public static void clearLow(Pixel p) {
    	
        // extract the red, green, and blue values from the pixel
        int r = p.getRed();
        int g = p.getGreen();
        int b = p.getBlue();
        
        // (1.6): clear the lowest two bits of each RGB component
        r = r / 4 * 4;
        g = g / 4 * 4;
        b = b / 4 * 4;
        
        // (1.7): set the red, green, and blue component values of
        // the pixel to the new values using the RGB setter methods
        p.setRed(r);
        p.setGreen(g);
        p.setBlue (b);

    }

    // create a copy of a picture and clear the lower two bits of each
    // pixel in the copy using the clearLow() method
    public static Picture testClearLow(Picture original) {
    	
        // create a new picture as a copy of the original
        Picture copy = new Picture(original);
        
        // get the array of pixels from the copy
        Pixel[] pixels = copy.getPixels();
        
        // (1.8): use a for each loop to iterate over the pixels
        // array and clear the low bits of each pixel in the array
        for (Pixel i : pixels) {
        	clearLow(i);
        }

        // return the copy
        return copy;
    }

    //////////////////////////////////////////////////
    // Setting Bits (Exercise 1.10-1.12)

    // set the lower (rightmost) two bits of each RGB in a pixel
    // to the higher (leftmost) two bits of each RGB in Color c
    public static void setLow(Pixel p, Color c) {
    	
        // clear the lowest 2 bits for each RGB value of the pixel
        clearLow(p);
        
        // get the RGB components from the Color parameter
        int r = c.getRed();
        int g = c.getGreen();
        int b = c.getBlue();
        
        // (1.10): get the highest two bits of each RGB component
        r = r / 64;
        g = g / 64;
        b = b / 64;

        // (1.11): store the highest two bits of each RGB component
        // in the lower two bits of the "cleared" pixel
        p.setRed(p.getRed() + r);
        p.setGreen(p.getGreen() + g);
        p.setBlue(p.getBlue() + b);
        
    }

    // create a copy of a picture; clear the lower two bits of the copy,
    // then set the lower two bits to the higher two bits of a color
    public static Picture testSetLow(Picture original, Color c) {
    	
        // create a new picture as a copy of the original
        Picture copy = new Picture(original);
        
        // get the array of pixels from the copy
        Pixel[] pixels = copy.getPixels();
        
        // (1.12): use a for each loop to iterate over the pixels;
        // set the lower two bits to the higher two bits of the color
        for (Pixel p : pixels) {
        	setLow(p, c);
        }

        // return the copy
        return copy;
    }

    //////////////////////////////////////////////////
    // Revealing Bits (Exercise 1.13-1.14)

    // create a blank picture; reveal the hidden picture in the source
    // by setting the highest two bits of each pixel in the blank image
    // extracted from the lowest two bits of each pixel in the source
    public static Picture revealPicture(Picture hidden) {
    	
        // get the 2D array of pixels from the source image
        Pixel[][] source = hidden.getPixels2D();
        
        // create a new (blank) picture with the same dimensions as the
        // picture that will contain the hidden image
        Picture revealed = new Picture(hidden.getWidth(), hidden.getHeight());
        
        // get the 2D array of pixels from the new (blank) picture
        Pixel[][] target = revealed.getPixels2D();
        
        // (1.13): iterate over the 2D array of the source pixels
        // using a nested for loop
        //get hidden red, blue, green and then do %4*64 to manipulate the last two bits to the front
        for (int i = 0; i < source.length; i++) {
        	
            for (int j = 0; j < source[0].length; j++) {
            	
                //(1.14): get the lowest two bits of the each RGB
                // component value from the source pixels in the hidden
                // and then set those values as the highest two bits in
                // corresponding "target" pixel in the revealed image
                int r = source[i][j].getRed() % 4;
                int g = source[i][j].getGreen() % 4;
                int b = source[i][j].getBlue() % 4;
                
                target[i][j].setRed(r * 64);
                target[i][j].setGreen(g * 64);
                target[i][j].setBlue(b * 64);
            
            }
            
        }
        
        // return the revealed image
        return revealed;
    }

    ////////////////////////////////////////////////////////////////////
    //
    // ACTIVITY 2 Methods: Hiding and Revealing a Picture
    //

    // Exercise 2.8
    // returns true if source and secret images have the same dimensions
    //
    // **ATTENTION**:
    // Do not rewrite this method for exercise 3.0!  There is a separate
    // overloaded canHide() method that exists in the Activity 3 section
    // where the overloaded method will be implemented.
    //
    public static boolean canHide(Picture source, Picture secret) {
        // (2.8): determine whether secret can be hidden in source,
        // which for this activity is only true if both the source image
        // and the secret image have the same exact dimensions
        if ((source.getHeight() == secret.getHeight()) && (source.getWidth() == secret.getWidth())) {
        	return true;
        }
        return false;
    }

    // Exercise 2.9
    // creates a new Picture with data from secret hidden in the RGB
    // information of source (source has same dimensions as secret)
    public static Picture hidePicture(Picture source, Picture secret) {
    	
        // (2.9): hide a secret picture within a source picture
        Picture copy = new Picture(source);
        Pixel [][] hide = secret.getPixels2D();
        Pixel [][] target = copy.getPixels2D();
        
        for (int i = 0; i < target.length; i++) {
        	for(int  j = 0; j < target[0].length; j++) {
        		setLow(target[i][j], hide[i][j].getColor());
        	}
        }
        
        return copy;
    }

    ////////////////////////////////////////////////////////////////////
    //
    // ACTIVITY 3 Methods: Identifying a Hidden Picture
    //

    // Exercise 3.0
    // returns true if secret image can be embedded in the source image
    // at the specified row and column without exceeding the maximum
    // bounds of the source image. (maxrows = height, maxcols = width)
    public static boolean canHide(Picture source, Picture secret,
                                  int row, int col) {
        // (3.0): determine whether the secret image can be
        // hidden inside the source image at position [row][col]
    	if (secret.getHeight() > source.getHeight() || secret.getWidth() > source.getWidth()) {
        	return false;
        }
        else if (row > source.getHeight() || col > source.getWidth()) {
        	return false;
        }
        else if (col + secret.getWidth() > source.getWidth() || row + secret.getHeight() > source.getHeight() ) {
        	return false;	
        }
        else if (row < 0 || col < 0) {
        	return false;
        }
        else {
        	return true;
        }
    }

    // Exercise 3.1
    // creates a new Picture with data from secret hidden in the RGB
    // information in source beginning at pixel location (row, col)
    public static Picture hidePicture(Picture source, Picture secret,
                                      int row, int col) {
        // (3.1): hide a secret image within a source image that is
        // anchored at position [row][col] in the source image
    	Picture copy = new Picture(source);
        Pixel [][] hide = secret.getPixels2D();
        Pixel [][] target = copy.getPixels2D();
        
        for (int i = 0; i < hide.length; i++) {
        	for(int j = 0; j < hide[0].length; j++) {
        		setLow(target[row+i][col+j], hide[i][j].getColor());
        	}
        }
        
        return copy;
    }

    // Exercise 3.2
    // checks to see if two images are exactly the same
    public static boolean isSame(Picture image1, Picture image2) {
        // images won't be the same if the width or height is different
        if ((image1.getWidth() != image2.getWidth()) ||
            (image1.getHeight() != image2.getHeight())) {
            return false;
        }
        // get the 2D array of pixels for each image
        Pixel[][] pixels1 = image1.getPixels2D();
        Pixel[][] pixels2 = image2.getPixels2D();
        // (3.2): compare the RGB values of pixel pairs at each
        // position [i][j] using a nested for loop
        for (int i = 0; i < pixels1.length; i++) {
        	for(int  j = 0; j < pixels1[0].length; j++) {
        		if(!pixels1[i][j].getColor().equals(pixels2[i][j].getColor())) {
        			return false;
        		}
        	}
        }
        return true;
    }

    // Exercise 3.3
    // returns arrayList of Points where pictures differ
    public static ArrayList<Point> findDifferences(Picture image1,
                                                   Picture image2) {
        // create an ArrayList of Point objects
        ArrayList<Point> points = new ArrayList<Point>();
        // return an empty list if the images are different sizes
        if (image1.getWidth() != image2.getWidth() ||
            image1.getHeight() != image2.getHeight()) {
            return points;
        }
        // get the 2D array of pixels for each image
        Pixel[][] pixels1 = image1.getPixels2D();
        Pixel[][] pixels2 = image2.getPixels2D();
        // (3.3): create an ArrayList of points that contain all
        // of the positions where the RGB values differ between pixels.
        // compare RGB values of pixel pairs using a nested for loop
        for (int i = 0; i < pixels1.length; i++) {
        	for(int  j = 0; j < pixels1[0].length; j++) {
        		
        		if(!pixels1[i][j].getColor().equals(pixels2[i][j].getColor())) {
        			Point p = new Point (i, j);
        			points.add(p);
        		}
        		
        	}
        }
        return points;
    }

    // Exercise 3.4
    // Draw a rectangular outline around the area that bounds the points
    // where the RGB values are different from the original image
    public static Picture showDifferentArea(Picture image, ArrayList<Point> points) {
        // create a new picture as a copy of the original
        Picture copy = new Picture(image);
        // no need to draw a bounding box if the point list is empty
        if (points.size() == 0) {
            return copy;
        }

        // TASK 1
        // calculate the minimum and maximum row values as well as the
        // minimum and maximum column values for the bounding box that
        // contain all the points in the list

        // create four variables for the min and max row and column
        int minRow, maxRow, minCol, maxCol;
        // initialize the min and max values to the first point
        minRow = points.get(0).getRow();
        maxRow = points.get(0).getRow();
        minCol = points.get(0).getCol();
        maxCol = points.get(0).getCol();
        // (3.4 part1): loop over the remaining points in the list
        // and find the minimum and maximum values of the bounding box
        for (Point p : points) {
        	if (p.getRow() < minRow) {
        		minRow = p.getRow();
        	}
        	if (p.getRow() > maxRow) {
        		maxRow = p.getRow();
        	}
        	if (p.getCol() < minCol) {
        		minCol = p.getCol();
        	}
        	if (p.getCol() > maxCol) {
        		maxCol = p.getCol();
        	}
        }

        // TASK 2
        // draw bounding box outline using a bright red (255, 0, 0)

        // get the 2D array of pixels from the copy image
        Pixel[][] pixels = copy.getPixels2D();
        // (3.4 part2): using a loop, "draw" the two horizontal
        // lines of the bounding box by setting the pixels of the sides
        // of the box to the RGB values of a bright red color
        for (int i = minCol; i < maxCol; i++) {
        	pixels[minRow][i].setRed(255);
        	pixels[minRow][i].setGreen(0);
        	pixels[minRow][i].setBlue(0);
        }
        
        for (int i = minCol; i < maxCol; i++) {
        	pixels[maxRow][i].setRed(255);
        	pixels[maxRow][i].setGreen(0);
        	pixels[maxRow][i].setBlue(0);
        }

        // (3.4 part3): using a loop, "draw" the two vertical lines
        // of the bounding box by setting the pixels of the sides of the
        // box to the RGB values of a bright red color
        for (int i = minRow; i < maxRow; i++) {
        	pixels[i][minCol].setRed(255);
        	pixels[i][minCol].setGreen(0);
        	pixels[i][minCol].setBlue(0);
        } 
        
        for (int i = minRow; i < maxRow; i++) {
        	pixels[i][maxCol].setRed(255);
        	pixels[i][maxCol].setGreen(0);
        	pixels[i][maxCol].setBlue(0);
        }

        // return the copy
        return copy;
    }

    ////////////////////////////////////////////////////////////////////
    //
    // ACTIVITY 4 Methods: Hiding and Revealing a Text Message
    //

    // Provided by the College Board
    // Accepts a string of characters and encodes the string into an
    // ArrayList of integer values based on the following mapping:
    //
    //    1-26 for A-Z
    //   27-52 for a-z
    //   53-62 for 0-9
    //      63 for space
    //
    // A terminating 0 is always added to the end of the list.
    //
    private static ArrayList<Integer> encodeString(String s) {
        String alpha = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789 ";
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (int i = 0; i < s.length(); i++) {
            result.add(alpha.indexOf(s.substring(i, i + 1)) + 1);
        }
        // terminate the list with a zero
        result.add(0);
        // return the list
        return result;
    }

    // Provided by the College Board
    // Accepts an ArrayList of integer values and decodes the numbers
    // into a string of characters based on the following mapping:
    //
    //    1-26 for A-Z
    //   27-52 for a-z
    //   53-62 for 0-9
    //      63 for space
    //
    private static String decodeString(ArrayList<Integer> codes) {
        String result = "";
        String alpha = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789 ";
        for (int i = 0; i < codes.size(); i++) {
            result = result + alpha.substring(codes.get(i) - 1, codes.get(i));
        }
        return result;
    }

    // Provided by the College Board
    // Given an integer from 0 to 63, creates and returns a 3-element
    // integer array consisting of the integers representing the pairs
    // of bits in the number from right to left.  For example:
    //
    //    27 (lower case a) in binary is 011011
    //                                   ^^^^^^
    //    bit pair [0] will be '01' or 1
    //    bit pair [1] will be '10' or 2
    //    bit pair [2] will be '11' or 3
    //
    private static int[] getBitPairs(int num) {
        int[] bits = new int[3];
        int code = num;
        for (int i = 2; i >= 0; i--) {
            bits[i] = code % 4;
            code = code / 4;
        }
        return bits;
    }

    
    /**public static void clearLow(Pixel p) {
    	
        // extract the red, green, and blue values from the pixel
        int r = p.getRed();
        int g = p.getGreen();
        int b = p.getBlue();
        
        // (1.6): clear the lowest two bits of each RGB component
        r = r / 4 * 4;
        g = g / 4 * 4;
        b = b / 4 * 4;
        
        // (1.7): set the red, green, and blue component values of
        // the pixel to the new values using the RGB setter methods
        p.setRed(r);
        p.setGreen(g);
        p.setBlue (b);
    **/
    
    // Exercise 4.2
    // hides a string (that consists only of upper and lower case
    // letters, numbers, and spaces) inside of a picture. The string is
    // hidden within the picture starting in the upper left corner.
    public static Picture hideText(Picture image, String s) {
        // use the method provided by the College Board to create
        // a list of integers that represents the encoded message,
        // which is always terminated by a zero (0)
        ArrayList<Integer> list = encodeString(s);
        // create a new picture as a copy of the original
        Picture copy = new Picture(image);
        // (4.2): loop through the list of integers that represent
        // each letter of the encoded message, split up each the integer
        // into bit pairs, then hide the bit pairs in the RGB components
        // of the image pixels beginning at the top left of the image
        
        Pixel [] target = copy.getPixels();
        
        if (list.size() > target.length) {
        	while (list.size() > target.length) {
        		list.remove(list.size()-1);
        	}
        }
        
        for (int i = 0; i <= list.size()-1; i++) {
        	clearLow(target[i]);
        	int [] bits = getBitPairs(list.get(i));
        	
        	target[i].setRed(target[i].getRed() + bits[0]);
        	target[i].setGreen(target[i].getGreen() + bits[1]);
        	target[i].setBlue(target[i].getBlue() + bits[2]);
        }
        
        // return the copy
        return copy;
    }

    // Exercise 4.3
    // reveals the string that has been hidden in the RGB values of the
    // pixels in a picture beginning at the top left of the image
    public static String revealText(Picture source) {
        // create an arrayList of Integer type to store the encoded text
        ArrayList<Integer> list = new ArrayList<Integer>();
        // (4.3): loop though the pixels in the image (beginning)
        // at the top left hand corner and extract the hidden message
        
        Pixel [] target = source.getPixels();
        
        for (int i = 0; i < target.length; i++) {
        	if (((target[i].getRed() & 3) == 0) && ((target[i].getGreen() & 3) == 0) && ((target[i].getBlue() & 3) == 0)) {
        		break;
        	}
        	
        	int counter = 0;
        	counter += (target[i].getRed() & 3) * 16;
        	counter += (target[i].getGreen() & 3) * 4;
        	counter += (target[i].getBlue() & 3);
        	list.add(counter);        	
        }
        
        // return the revealed text
        return decodeString(list);
    }

}
