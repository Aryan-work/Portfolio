import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class SteganographyTestActivity2 {

    @Test
    public void testCanHide1of4() {
        // create two pictures
        Picture p1 = new Picture(640, 480);
        Picture p2 = new Picture(640, 480);
        // run the test
        assertTrue(Steganography.canHide(p1, p2));
    }

    @Test
    public void testCanHide2of4() {
        // create two pictures
        Picture p1 = new Picture(640, 480);
        Picture p2 = new Picture(640, 479);
        // run the test
        assertFalse(Steganography.canHide(p1, p2));
    }

    @Test
    public void testCanHide3of4() {
        // create two pictures
        Picture p1 = new Picture(640, 480);
        Picture p2 = new Picture(641, 480);
        // run the test
        assertFalse(Steganography.canHide(p1, p2));
    }

    @Test
    public void testCanHide4of4() {
        // create two pictures
        Picture p1 = new Picture(640, 480);
        Picture p2 = new Picture(641, 479);
        // run the test
        assertFalse(Steganography.canHide(p1, p2));
    }

    @Test
    public void testHidePicture1of11() {
        // create two pictures
        Picture swan = new Picture("img/swan.jpg");
        Picture gorge = new Picture("img/gorge.jpg");
        // run the test
        Picture combined = Steganography.hidePicture(swan, gorge);
        assertNotNull(combined);
    }

    @Test
    public void testHidePicture2of11() {
        // create two pictures
        Picture swan = new Picture("img/swan.jpg");
        Picture gorge = new Picture("img/gorge.jpg");
        // run the test
        Picture combined = Steganography.hidePicture(swan, gorge);
        assertNotSame(swan, combined);
    }

    // tests 3-5 check pixel[100][380] for RGB(77, 49, 44)
    @Test
    public void testHidePicture3of11() {
        // create two pictures
        Picture swan = new Picture("img/swan.jpg");
        Picture gorge = new Picture("img/gorge.jpg");
        // run the test
        Picture combined = Steganography.hidePicture(swan, gorge);
        Pixel[][] pixels = combined.getPixels2D();
        assertEquals(77, pixels[100][380].getRed());
    }
    @Test
    public void testHidePicture4of11() {
        // create two pictures
        Picture swan = new Picture("img/swan.jpg");
        Picture gorge = new Picture("img/gorge.jpg");
        // run the test
        Picture combined = Steganography.hidePicture(swan, gorge);
        Pixel[][] pixels = combined.getPixels2D();
        assertEquals(49, pixels[100][380].getGreen());
    }
    @Test
    public void testHidePicture5of11() {
        // create two pictures
        Picture swan = new Picture("img/swan.jpg");
        Picture gorge = new Picture("img/gorge.jpg");
        // run the test
        Picture combined = Steganography.hidePicture(swan, gorge);
        Pixel[][] pixels = combined.getPixels2D();
        assertEquals(44, pixels[100][380].getBlue());
    }

    // tests 6-8 check pixel[250][225] for RGB(210, 206, 201)
    @Test
    public void testHidePicture6of11() {
        // create two pictures
        Picture swan = new Picture("img/swan.jpg");
        Picture gorge = new Picture("img/gorge.jpg");
        // run the test
        Picture combined = Steganography.hidePicture(swan, gorge);
        Pixel[][] pixels = combined.getPixels2D();
        assertEquals(210, pixels[250][225].getRed());
    }
    @Test
    public void testHidePicture7of11() {
        // create two pictures
        Picture swan = new Picture("img/swan.jpg");
        Picture gorge = new Picture("img/gorge.jpg");
        // run the test
        Picture combined = Steganography.hidePicture(swan, gorge);
        Pixel[][] pixels = combined.getPixels2D();
        assertEquals(206, pixels[250][225].getGreen());
    }
    @Test
    public void testHidePicture8of11() {
        // create two pictures
        Picture swan = new Picture("img/swan.jpg");
        Picture gorge = new Picture("img/gorge.jpg");
        // run the test
        Picture combined = Steganography.hidePicture(swan, gorge);
        Pixel[][] pixels = combined.getPixels2D();
        assertEquals(201, pixels[250][225].getBlue());
    }

    // tests 9-11 check pixel[125][150] for RGB(61, 60, 56)
    @Test
    public void testHidePicture9of11() {
        // create two pictures
        Picture swan = new Picture("img/swan.jpg");
        Picture gorge = new Picture("img/gorge.jpg");
        // run the test
        Picture combined = Steganography.hidePicture(swan, gorge);
        Pixel[][] pixels = combined.getPixels2D();
        assertEquals(61, pixels[125][150].getRed());
    }
    @Test
    public void testHidePicture10of11() {
        // create two pictures
        Picture swan = new Picture("img/swan.jpg");
        Picture gorge = new Picture("img/gorge.jpg");
        // run the test
        Picture combined = Steganography.hidePicture(swan, gorge);
        Pixel[][] pixels = combined.getPixels2D();
        assertEquals(60, pixels[125][150].getGreen());
    }
    @Test
    public void testHidePicture11of11() {
        // create two pictures
        Picture swan = new Picture("img/swan.jpg");
        Picture gorge = new Picture("img/gorge.jpg");
        // run the test
        Picture combined = Steganography.hidePicture(swan, gorge);
        Pixel[][] pixels = combined.getPixels2D();
        assertEquals(56, pixels[125][150].getBlue());
    }
}
