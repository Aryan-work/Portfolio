import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class SteganographyTestActivity4 {
    
    private static final String STORMING_TEXT = "HAVE FUN STORMING THE CASTLE";

    @Test
    public void testHideText1of7() {
        // create a picture
        Picture test = new Picture("img/beach.jpg");
        // run the test
        Picture hidden = Steganography.hideText(test, STORMING_TEXT);
        assertNotSame(test, hidden);
    }

    @Test
    public void testHideText2of7() {
        // create a picture
        Picture test = new Picture("img/beach.jpg");
        // run the test
        Picture hidden = Steganography.hideText(test, STORMING_TEXT);
        Pixel[][] pixels = hidden.getPixels2D();
        // 'V' (1, 1, 2) should be stored in 3rd pixel of the 1st row
        assertTrue(pixels[0][2].getRed() % 4 == 1 && 
                   pixels[0][2].getGreen() % 4 == 1 &&
                   pixels[0][2].getBlue() % 4 == 2);
    }

    @Test
    public void testHideText3of7() {
        // create a picture
        Picture test = new Picture("img/redMotorcycle.jpg");
        // run the test
        Picture hidden = Steganography.hideText(test, STORMING_TEXT);
        Pixel[][] pixels = hidden.getPixels2D();
        // 'V' (1, 1, 2) should be stored in 3rd pixel of the 1st row
        // but upper 6 pixels of each component should be unchanged
        assertTrue(pixels[0][2].getRed() / 4 * 4 == 204 && 
                   pixels[0][2].getGreen() / 4 * 4 == 172 &&
                   pixels[0][2].getBlue() / 4 * 4 == 140);
    }

    @Test
    public void testHideText4of7() {
        // create a picture
        Picture test = new Picture("img/beach.jpg");
        // run the test
        Picture hidden = Steganography.hideText(test, STORMING_TEXT);
        Pixel[][] pixels = hidden.getPixels2D();
        // low bits of (0, 0, 0) indicates end of message
        int len = STORMING_TEXT.length();
        assertTrue(pixels[0][len].getRed() % 4 == 0 && 
                   pixels[0][len].getGreen() % 4 == 0 &&
                   pixels[0][len].getBlue() % 4 == 0);
    }

    @Test
    public void testHideText5of7() {
        // create a picture
        Picture test = new Picture("img/beach.jpg");
        // run the test
        Picture hidden = Steganography.hideText(test, STORMING_TEXT);
        Pixel[][] source = test.getPixels2D();
        Pixel[][] pixels = hidden.getPixels2D();
        // no pixels after end of message should have changed
        int len = STORMING_TEXT.length();
        assertTrue(pixels[0][len + 1].getRed() == source[0][29].getRed() &&
                   pixels[0][len + 1].getGreen() == source[0][29].getGreen() &&
                   pixels[0][len + 1].getBlue() == source[0][29].getBlue());
    }

    @Test
    public void testHideText6of7() {
        // create a picture
        Picture test = new Picture("img/robot.jpg");
        // run the test
        String text = "Hello My name is Inigo Montoya you killed my father prepare to die ";
        text += text;
        text += text;
        text = text.trim();
        Picture hidden = Steganography.hideText(test, text);
        Pixel[] source = test.getPixels();
        Pixel[] pixels = hidden.getPixels();
        // count the number of pixels that were modified
        int changed = 0;
        for (int i = 0; i < source.length; i++) {
            if (source[i].getRed() != pixels[i].getRed() ||
                source[i].getGreen() != pixels[i].getGreen() ||
                source[i].getBlue() != pixels[i].getBlue()) {
                changed++;
            }
        }
        assertEquals(233, changed);
    }

    @Test
    public void testHideText7of7() {
        // create a picture
        Picture test = new Picture("img/robot.jpg");
        // run the test
        String text = "Hello My name is Inigo Montoya you killed my father prepare to die ";
        text += text + text + text + text;
        text += text + text + text + text;
        text += text + text + text + text;
        text = text.trim();
        Picture hidden = Steganography.hideText(test, text);
        Pixel[] source = test.getPixels();
        Pixel[] pixels = hidden.getPixels();
        // count the number of pixels that were modified
        int changed = 0;
        for (int i = 0; i < source.length; i++) {
            if (source[i].getRed() != pixels[i].getRed() ||
                source[i].getGreen() != pixels[i].getGreen() ||
                source[i].getBlue() != pixels[i].getBlue()) {
                changed++;
            }
        }
        assertEquals(2732, changed);
    }

    @Test
    public void testRevealText1of3() {
        // create a picture
        Picture test = new Picture("img/beach.jpg");
        // run the test
        String text = "HAVE FUN STORMING THE CASTLE";
        Picture hidden = Steganography.hideText(test, text);
        String revealed = Steganography.revealText(hidden);
        assertEquals(text, revealed);
    }

    @Test
    public void testRevealText2of3() {
        // create a picture
        Picture test = new Picture("img/robot.jpg");
        // run the test
        String text = "Hello My name is Inigo Montoya you killed my father prepare to die ";
        text += text;
        text += text;
        text = text.trim();
        Picture hidden = Steganography.hideText(test, text);
        String revealed = Steganography.revealText(hidden);
        assertEquals(text, revealed);
    }

    @Test
    public void testRevealText3of3() {
        // create a picture
        Picture test = new Picture("img/robot.jpg");
        // run the test
        String text = "Hello My name is Inigo Montoya you killed my father prepare to die ";
        text += text + text + text + text;
        text += text + text + text + text;
        text += text + text + text + text;
        text = text.trim();
        Picture hidden = Steganography.hideText(test, text);
        String revealed = Steganography.revealText(hidden);
        assertEquals(test.getWidth() * test.getHeight(), revealed.length());
    }
}
